﻿namespace Project
{
    partial class SignIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignIn));
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.Image = new MetroFramework.Controls.MetroLabel();
            this.SigninButton = new MetroFramework.Controls.MetroButton();
            this.UsertypeCombo = new MetroFramework.Controls.MetroComboBox();
            this.userTypeBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this._C__ProjectDataSet3 = new Project._C__ProjectDataSet();
            this.userTypeBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.userTypeBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.uTypeBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this._C__ProjectDataSet = new Project._C__ProjectDataSet();
            this.userTypeBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.uTDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.projectDataSet6 = new Project.ProjectDataSet6();
            this.Usertype = new MetroFramework.Controls.MetroLabel();
            this.Mobiletext = new System.Windows.Forms.MaskedTextBox();
            this.Password = new MetroFramework.Controls.MetroTextBox();
            this.Emailtext = new MetroFramework.Controls.MetroTextBox();
            this.Pass = new MetroFramework.Controls.MetroLabel();
            this.Usernametext = new MetroFramework.Controls.MetroTextBox();
            this.Email = new MetroFramework.Controls.MetroLabel();
            this.Username = new MetroFramework.Controls.MetroLabel();
            this.Gendercombo = new MetroFramework.Controls.MetroComboBox();
            this.Date = new MetroFramework.Controls.MetroDateTime();
            this.Citytext = new MetroFramework.Controls.MetroTextBox();
            this.Addresstext = new MetroFramework.Controls.MetroTextBox();
            this.Fathernametext = new MetroFramework.Controls.MetroTextBox();
            this.Lastnametext = new MetroFramework.Controls.MetroTextBox();
            this.Firstnametext = new MetroFramework.Controls.MetroTextBox();
            this.City = new MetroFramework.Controls.MetroLabel();
            this.Gender = new MetroFramework.Controls.MetroLabel();
            this.DateOfBirth = new MetroFramework.Controls.MetroLabel();
            this.Address = new MetroFramework.Controls.MetroLabel();
            this.MobileNo = new MetroFramework.Controls.MetroLabel();
            this.FatherName = new MetroFramework.Controls.MetroLabel();
            this.LastName = new MetroFramework.Controls.MetroLabel();
            this.FirstName = new MetroFramework.Controls.MetroLabel();
            this.Studentpanel = new System.Windows.Forms.Panel();
            this.SemesterCombo = new MetroFramework.Controls.MetroComboBox();
            this.Semester = new MetroFramework.Controls.MetroLabel();
            this.RegNo = new MetroFramework.Controls.MetroLabel();
            this.RegNoText = new MetroFramework.Controls.MetroTextBox();
            this.techBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this._C__ProjectDataSet31 = new Project._C__ProjectDataSet3();
            this.displineBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this._C__ProjectDataSet2 = new Project._C__ProjectDataSet();
            this.departCombo = new MetroFramework.Controls.MetroComboBox();
            this.departmentBindingSource7 = new System.Windows.Forms.BindingSource(this.components);
            this.Department = new MetroFramework.Controls.MetroLabel();
            this.departmentDataBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.projectDataSet3 = new Project.ProjectDataSet3();
            this.departmentBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.projectDataSet2 = new Project.ProjectDataSet();
            this.projectDataSet = new Project.ProjectDataSet();
            this.Pic = new MetroFramework.Controls.MetroTextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.departmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.departmentTableAdapter = new Project.ProjectDataSetTableAdapters.DepartmentTableAdapter();
            this.projectDataSet1 = new Project.ProjectDataSet1();
            this.departmentBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.departmentTableAdapter1 = new Project.ProjectDataSet1TableAdapters.DepartmentTableAdapter();
            this.departmentBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.departmentBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.projectDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.departmentBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.projectDataSet21 = new Project.ProjectDataSet2();
            this.departmentDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.departmentDataTableAdapter = new Project.ProjectDataSet2TableAdapters.DepartmentDataTableAdapter();
            this.fKUserDataDepID2A4B4B5EBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.userDataTableAdapter = new Project.ProjectDataSet2TableAdapters.UserDataTableAdapter();
            this.departmentDataBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.departmentDataTableAdapter1 = new Project.ProjectDataSet3TableAdapters.DepartmentDataTableAdapter();
            this.projectDataSet3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.projectDataSet4 = new Project.ProjectDataSet4();
            this.userTypeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.userTypeTableAdapter = new Project.ProjectDataSet4TableAdapters.UserTypeTableAdapter();
            this.projectDataSet5 = new Project.ProjectDataSet5();
            this.uTypeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.uTypeTableAdapter = new Project.ProjectDataSet5TableAdapters.UTypeTableAdapter();
            this.uTypeBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.uTDataTableAdapter = new Project.ProjectDataSet6TableAdapters.UTDataTableAdapter();
            this.userTypeTableAdapter1 = new Project._C__ProjectDataSetTableAdapters.UserTypeTableAdapter();
            this.departmentBindingSource6 = new System.Windows.Forms.BindingSource(this.components);
            this.departmentTableAdapter2 = new Project._C__ProjectDataSetTableAdapters.DepartmentTableAdapter();
            this._C__ProjectDataSet1 = new Project._C__ProjectDataSet();
            this.displineBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.displineTableAdapter = new Project._C__ProjectDataSetTableAdapters.DisplineTableAdapter();
            this.uTypeTableAdapter1 = new Project._C__ProjectDataSetTableAdapters.UTypeTableAdapter();
            this.user_TypeTableAdapter = new Project._C__ProjectDataSetTableAdapters.User_TypeTableAdapter();
            this.userDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.userDataTableAdapter1 = new Project._C__ProjectDataSetTableAdapters.UserDataTableAdapter();
            this._C__ProjectDataSet21 = new Project._C__ProjectDataSet2();
            this.userDataBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.userDataTableAdapter2 = new Project._C__ProjectDataSet2TableAdapters.UserDataTableAdapter();
            this.semesterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.semesterTableAdapter = new Project._C__ProjectDataSet2TableAdapters.SemesterTableAdapter();
            this.techBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.techTableAdapter = new Project._C__ProjectDataSet3TableAdapters.TechTableAdapter();
            this.Error = new MetroFramework.Controls.MetroLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.TechCombo = new MetroFramework.Controls.MetroComboBox();
            this.Tech = new MetroFramework.Controls.MetroLabel();
            this._C__ProjectDataSet7 = new Project._C__ProjectDataSet7();
            this.departmentBindingSource8 = new System.Windows.Forms.BindingSource(this.components);
            this.departmentTableAdapter3 = new Project._C__ProjectDataSet7TableAdapters.DepartmentTableAdapter();
            this.departmentBindingSource9 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.userTypeBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userTypeBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userTypeBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uTypeBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userTypeBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uTDataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet6)).BeginInit();
            this.Studentpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.techBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.displineBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentDataBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentDataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKUserDataDepID2A4B4B5EBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentDataBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userTypeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uTypeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uTypeBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.displineBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userDataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userDataBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.semesterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.techBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource9)).BeginInit();
            this.SuspendLayout();
            // 
            // metroButton2
            // 
            this.metroButton2.FontWeight = MetroFramework.MetroButtonWeight.Light;
            this.metroButton2.Location = new System.Drawing.Point(694, 143);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(87, 23);
            this.metroButton2.TabIndex = 61;
            this.metroButton2.Text = "Choose Image";
            this.metroButton2.UseSelectable = true;
            this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // Image
            // 
            this.Image.AutoSize = true;
            this.Image.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Image.Location = new System.Drawing.Point(592, 113);
            this.Image.Name = "Image";
            this.Image.Size = new System.Drawing.Size(95, 19);
            this.Image.TabIndex = 60;
            this.Image.Text = "Upload Image";
            // 
            // SigninButton
            // 
            this.SigninButton.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.SigninButton.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.SigninButton.Location = new System.Drawing.Point(405, 447);
            this.SigninButton.Name = "SigninButton";
            this.SigninButton.Size = new System.Drawing.Size(128, 39);
            this.SigninButton.TabIndex = 59;
            this.SigninButton.Text = "Sign In";
            this.SigninButton.UseSelectable = true;
            this.SigninButton.Click += new System.EventHandler(this.SigninButton_Click);
            // 
            // UsertypeCombo
            // 
            this.UsertypeCombo.DataSource = this.userTypeBindingSource4;
            this.UsertypeCombo.DisplayMember = "Usertype";
            this.UsertypeCombo.FormattingEnabled = true;
            this.UsertypeCombo.ItemHeight = 23;
            this.UsertypeCombo.Location = new System.Drawing.Point(694, 171);
            this.UsertypeCombo.Name = "UsertypeCombo";
            this.UsertypeCombo.Size = new System.Drawing.Size(174, 29);
            this.UsertypeCombo.TabIndex = 58;
            this.UsertypeCombo.UseSelectable = true;
            this.UsertypeCombo.ValueMember = "UID";
            this.UsertypeCombo.SelectedIndexChanged += new System.EventHandler(this.UsertypeCombo_SelectedIndexChanged);
            // 
            // userTypeBindingSource4
            // 
            this.userTypeBindingSource4.DataMember = "User_Type";
            this.userTypeBindingSource4.DataSource = this._C__ProjectDataSet3;
            // 
            // _C__ProjectDataSet3
            // 
            this._C__ProjectDataSet3.DataSetName = "_C__ProjectDataSet";
            this._C__ProjectDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // userTypeBindingSource3
            // 
            this.userTypeBindingSource3.DataMember = "UserType";
            this.userTypeBindingSource3.DataSource = this._C__ProjectDataSet3;
            // 
            // userTypeBindingSource2
            // 
            this.userTypeBindingSource2.DataMember = "UserType";
            this.userTypeBindingSource2.DataSource = this._C__ProjectDataSet3;
            // 
            // uTypeBindingSource2
            // 
            this.uTypeBindingSource2.DataMember = "UType";
            this.uTypeBindingSource2.DataSource = this._C__ProjectDataSet;
            // 
            // _C__ProjectDataSet
            // 
            this._C__ProjectDataSet.DataSetName = "_C__ProjectDataSet";
            this._C__ProjectDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // userTypeBindingSource1
            // 
            this.userTypeBindingSource1.DataMember = "UserType";
            this.userTypeBindingSource1.DataSource = this._C__ProjectDataSet;
            // 
            // uTDataBindingSource
            // 
            this.uTDataBindingSource.DataMember = "UTData";
            this.uTDataBindingSource.DataSource = this.projectDataSet6;
            // 
            // projectDataSet6
            // 
            this.projectDataSet6.DataSetName = "ProjectDataSet6";
            this.projectDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Usertype
            // 
            this.Usertype.AutoSize = true;
            this.Usertype.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Usertype.Location = new System.Drawing.Point(588, 181);
            this.Usertype.Name = "Usertype";
            this.Usertype.Size = new System.Drawing.Size(69, 19);
            this.Usertype.TabIndex = 57;
            this.Usertype.Text = "User Type";
            // 
            // Mobiletext
            // 
            this.Mobiletext.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Mobiletext.Location = new System.Drawing.Point(163, 180);
            this.Mobiletext.Mask = "0000-0000000";
            this.Mobiletext.Name = "Mobiletext";
            this.Mobiletext.Size = new System.Drawing.Size(188, 20);
            this.Mobiletext.TabIndex = 56;
            // 
            // Password
            // 
            // 
            // 
            // 
            this.Password.CustomButton.Image = null;
            this.Password.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Password.CustomButton.Name = "";
            this.Password.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Password.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Password.CustomButton.TabIndex = 1;
            this.Password.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Password.CustomButton.UseSelectable = true;
            this.Password.CustomButton.Visible = false;
            this.Password.Lines = new string[0];
            this.Password.Location = new System.Drawing.Point(164, 409);
            this.Password.MaxLength = 32767;
            this.Password.Name = "Password";
            this.Password.PasswordChar = '\0';
            this.Password.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Password.SelectedText = "";
            this.Password.SelectionLength = 0;
            this.Password.SelectionStart = 0;
            this.Password.ShortcutsEnabled = true;
            this.Password.Size = new System.Drawing.Size(188, 22);
            this.Password.TabIndex = 55;
            this.Password.UseSelectable = true;
            this.Password.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Password.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.Password.Click += new System.EventHandler(this.Password_Click);
            // 
            // Emailtext
            // 
            // 
            // 
            // 
            this.Emailtext.CustomButton.Image = null;
            this.Emailtext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Emailtext.CustomButton.Name = "";
            this.Emailtext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Emailtext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Emailtext.CustomButton.TabIndex = 1;
            this.Emailtext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Emailtext.CustomButton.UseSelectable = true;
            this.Emailtext.CustomButton.Visible = false;
            this.Emailtext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Emailtext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Emailtext.Lines = new string[] {
        "Email"};
            this.Emailtext.Location = new System.Drawing.Point(164, 378);
            this.Emailtext.MaxLength = 32767;
            this.Emailtext.Name = "Emailtext";
            this.Emailtext.PasswordChar = '\0';
            this.Emailtext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Emailtext.SelectedText = "";
            this.Emailtext.SelectionLength = 0;
            this.Emailtext.SelectionStart = 0;
            this.Emailtext.ShortcutsEnabled = true;
            this.Emailtext.Size = new System.Drawing.Size(188, 22);
            this.Emailtext.TabIndex = 54;
            this.Emailtext.Text = "Email";
            this.Emailtext.UseSelectable = true;
            this.Emailtext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Emailtext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Pass
            // 
            this.Pass.AutoSize = true;
            this.Pass.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Pass.Location = new System.Drawing.Point(33, 412);
            this.Pass.Name = "Pass";
            this.Pass.Size = new System.Drawing.Size(67, 19);
            this.Pass.TabIndex = 53;
            this.Pass.Text = "Password";
            // 
            // Usernametext
            // 
            // 
            // 
            // 
            this.Usernametext.CustomButton.Image = null;
            this.Usernametext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Usernametext.CustomButton.Name = "";
            this.Usernametext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Usernametext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Usernametext.CustomButton.TabIndex = 1;
            this.Usernametext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Usernametext.CustomButton.UseSelectable = true;
            this.Usernametext.CustomButton.Visible = false;
            this.Usernametext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Usernametext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Usernametext.Lines = new string[] {
        "User Name"};
            this.Usernametext.Location = new System.Drawing.Point(164, 345);
            this.Usernametext.MaxLength = 32767;
            this.Usernametext.Name = "Usernametext";
            this.Usernametext.PasswordChar = '\0';
            this.Usernametext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Usernametext.SelectedText = "";
            this.Usernametext.SelectionLength = 0;
            this.Usernametext.SelectionStart = 0;
            this.Usernametext.ShortcutsEnabled = true;
            this.Usernametext.Size = new System.Drawing.Size(188, 22);
            this.Usernametext.TabIndex = 52;
            this.Usernametext.Text = "User Name";
            this.Usernametext.UseSelectable = true;
            this.Usernametext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Usernametext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Email.Location = new System.Drawing.Point(33, 381);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(41, 19);
            this.Email.TabIndex = 51;
            this.Email.Text = "Email";
            // 
            // Username
            // 
            this.Username.AutoSize = true;
            this.Username.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Username.Location = new System.Drawing.Point(33, 348);
            this.Username.Name = "Username";
            this.Username.Size = new System.Drawing.Size(77, 19);
            this.Username.TabIndex = 50;
            this.Username.Text = "User Name";
            // 
            // Gendercombo
            // 
            this.Gendercombo.FormattingEnabled = true;
            this.Gendercombo.ItemHeight = 23;
            this.Gendercombo.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.Gendercombo.Location = new System.Drawing.Point(164, 275);
            this.Gendercombo.Name = "Gendercombo";
            this.Gendercombo.Size = new System.Drawing.Size(187, 29);
            this.Gendercombo.TabIndex = 49;
            this.Gendercombo.UseSelectable = true;
            // 
            // Date
            // 
            this.Date.Location = new System.Drawing.Point(164, 240);
            this.Date.MinimumSize = new System.Drawing.Size(0, 29);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(187, 29);
            this.Date.TabIndex = 48;
            // 
            // Citytext
            // 
            // 
            // 
            // 
            this.Citytext.CustomButton.Image = null;
            this.Citytext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Citytext.CustomButton.Name = "";
            this.Citytext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Citytext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Citytext.CustomButton.TabIndex = 1;
            this.Citytext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Citytext.CustomButton.UseSelectable = true;
            this.Citytext.CustomButton.Visible = false;
            this.Citytext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Citytext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Citytext.Lines = new string[] {
        "City"};
            this.Citytext.Location = new System.Drawing.Point(164, 311);
            this.Citytext.MaxLength = 32767;
            this.Citytext.Name = "Citytext";
            this.Citytext.PasswordChar = '\0';
            this.Citytext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Citytext.SelectedText = "";
            this.Citytext.SelectionLength = 0;
            this.Citytext.SelectionStart = 0;
            this.Citytext.ShortcutsEnabled = true;
            this.Citytext.Size = new System.Drawing.Size(188, 22);
            this.Citytext.TabIndex = 47;
            this.Citytext.Text = "City";
            this.Citytext.UseSelectable = true;
            this.Citytext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Citytext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Addresstext
            // 
            // 
            // 
            // 
            this.Addresstext.CustomButton.Image = null;
            this.Addresstext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Addresstext.CustomButton.Name = "";
            this.Addresstext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Addresstext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Addresstext.CustomButton.TabIndex = 1;
            this.Addresstext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Addresstext.CustomButton.UseSelectable = true;
            this.Addresstext.CustomButton.Visible = false;
            this.Addresstext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Addresstext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Addresstext.Lines = new string[] {
        "Address"};
            this.Addresstext.Location = new System.Drawing.Point(164, 210);
            this.Addresstext.MaxLength = 32767;
            this.Addresstext.Name = "Addresstext";
            this.Addresstext.PasswordChar = '\0';
            this.Addresstext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Addresstext.SelectedText = "";
            this.Addresstext.SelectionLength = 0;
            this.Addresstext.SelectionStart = 0;
            this.Addresstext.ShortcutsEnabled = true;
            this.Addresstext.Size = new System.Drawing.Size(188, 22);
            this.Addresstext.TabIndex = 46;
            this.Addresstext.Text = "Address";
            this.Addresstext.UseSelectable = true;
            this.Addresstext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Addresstext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Fathernametext
            // 
            // 
            // 
            // 
            this.Fathernametext.CustomButton.Image = null;
            this.Fathernametext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Fathernametext.CustomButton.Name = "";
            this.Fathernametext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Fathernametext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Fathernametext.CustomButton.TabIndex = 1;
            this.Fathernametext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Fathernametext.CustomButton.UseSelectable = true;
            this.Fathernametext.CustomButton.Visible = false;
            this.Fathernametext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Fathernametext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Fathernametext.Lines = new string[] {
        "Father Name"};
            this.Fathernametext.Location = new System.Drawing.Point(164, 144);
            this.Fathernametext.MaxLength = 32767;
            this.Fathernametext.Name = "Fathernametext";
            this.Fathernametext.PasswordChar = '\0';
            this.Fathernametext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Fathernametext.SelectedText = "";
            this.Fathernametext.SelectionLength = 0;
            this.Fathernametext.SelectionStart = 0;
            this.Fathernametext.ShortcutsEnabled = true;
            this.Fathernametext.Size = new System.Drawing.Size(188, 22);
            this.Fathernametext.TabIndex = 45;
            this.Fathernametext.Text = "Father Name";
            this.Fathernametext.UseSelectable = true;
            this.Fathernametext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Fathernametext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Lastnametext
            // 
            // 
            // 
            // 
            this.Lastnametext.CustomButton.Image = null;
            this.Lastnametext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Lastnametext.CustomButton.Name = "";
            this.Lastnametext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Lastnametext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Lastnametext.CustomButton.TabIndex = 1;
            this.Lastnametext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Lastnametext.CustomButton.UseSelectable = true;
            this.Lastnametext.CustomButton.Visible = false;
            this.Lastnametext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Lastnametext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Lastnametext.Lines = new string[] {
        "Last Name"};
            this.Lastnametext.Location = new System.Drawing.Point(164, 110);
            this.Lastnametext.MaxLength = 32767;
            this.Lastnametext.Name = "Lastnametext";
            this.Lastnametext.PasswordChar = '\0';
            this.Lastnametext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Lastnametext.SelectedText = "";
            this.Lastnametext.SelectionLength = 0;
            this.Lastnametext.SelectionStart = 0;
            this.Lastnametext.ShortcutsEnabled = true;
            this.Lastnametext.Size = new System.Drawing.Size(188, 22);
            this.Lastnametext.TabIndex = 44;
            this.Lastnametext.Text = "Last Name";
            this.Lastnametext.UseSelectable = true;
            this.Lastnametext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Lastnametext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Firstnametext
            // 
            // 
            // 
            // 
            this.Firstnametext.CustomButton.Image = null;
            this.Firstnametext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Firstnametext.CustomButton.Name = "";
            this.Firstnametext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Firstnametext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Firstnametext.CustomButton.TabIndex = 1;
            this.Firstnametext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Firstnametext.CustomButton.UseSelectable = true;
            this.Firstnametext.CustomButton.Visible = false;
            this.Firstnametext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Firstnametext.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Firstnametext.Lines = new string[] {
        "First Name"};
            this.Firstnametext.Location = new System.Drawing.Point(164, 80);
            this.Firstnametext.MaxLength = 32767;
            this.Firstnametext.Name = "Firstnametext";
            this.Firstnametext.PasswordChar = '\0';
            this.Firstnametext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Firstnametext.SelectedText = "";
            this.Firstnametext.SelectionLength = 0;
            this.Firstnametext.SelectionStart = 0;
            this.Firstnametext.ShortcutsEnabled = true;
            this.Firstnametext.Size = new System.Drawing.Size(188, 22);
            this.Firstnametext.TabIndex = 43;
            this.Firstnametext.Text = "First Name";
            this.Firstnametext.UseSelectable = true;
            this.Firstnametext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Firstnametext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // City
            // 
            this.City.AutoSize = true;
            this.City.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.City.Location = new System.Drawing.Point(33, 314);
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(33, 19);
            this.City.TabIndex = 42;
            this.City.Text = "City";
            // 
            // Gender
            // 
            this.Gender.AutoSize = true;
            this.Gender.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Gender.Location = new System.Drawing.Point(33, 285);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(54, 19);
            this.Gender.TabIndex = 41;
            this.Gender.Text = "Gender";
            // 
            // DateOfBirth
            // 
            this.DateOfBirth.AutoSize = true;
            this.DateOfBirth.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.DateOfBirth.Location = new System.Drawing.Point(33, 250);
            this.DateOfBirth.Name = "DateOfBirth";
            this.DateOfBirth.Size = new System.Drawing.Size(90, 19);
            this.DateOfBirth.TabIndex = 40;
            this.DateOfBirth.Text = "Date Of Birth";
            // 
            // Address
            // 
            this.Address.AutoSize = true;
            this.Address.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Address.Location = new System.Drawing.Point(33, 213);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(58, 19);
            this.Address.TabIndex = 39;
            this.Address.Text = "Address";
            // 
            // MobileNo
            // 
            this.MobileNo.AutoSize = true;
            this.MobileNo.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.MobileNo.Location = new System.Drawing.Point(33, 181);
            this.MobileNo.Name = "MobileNo";
            this.MobileNo.Size = new System.Drawing.Size(59, 19);
            this.MobileNo.TabIndex = 38;
            this.MobileNo.Text = "Mobile#";
            // 
            // FatherName
            // 
            this.FatherName.AutoSize = true;
            this.FatherName.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.FatherName.Location = new System.Drawing.Point(33, 147);
            this.FatherName.Name = "FatherName";
            this.FatherName.Size = new System.Drawing.Size(88, 19);
            this.FatherName.TabIndex = 37;
            this.FatherName.Text = "Father Name";
            // 
            // LastName
            // 
            this.LastName.AutoSize = true;
            this.LastName.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.LastName.Location = new System.Drawing.Point(33, 113);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(74, 19);
            this.LastName.TabIndex = 36;
            this.LastName.Text = "Last Name";
            // 
            // FirstName
            // 
            this.FirstName.AutoSize = true;
            this.FirstName.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.FirstName.Location = new System.Drawing.Point(33, 83);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(75, 19);
            this.FirstName.TabIndex = 35;
            this.FirstName.Text = "First Name";
            // 
            // Studentpanel
            // 
            this.Studentpanel.Controls.Add(this.SemesterCombo);
            this.Studentpanel.Controls.Add(this.Semester);
            this.Studentpanel.Controls.Add(this.RegNo);
            this.Studentpanel.Controls.Add(this.RegNoText);
            this.Studentpanel.Location = new System.Drawing.Point(577, 300);
            this.Studentpanel.Name = "Studentpanel";
            this.Studentpanel.Size = new System.Drawing.Size(326, 78);
            this.Studentpanel.TabIndex = 62;
            this.Studentpanel.Visible = false;
            // 
            // SemesterCombo
            // 
            this.SemesterCombo.FormattingEnabled = true;
            this.SemesterCombo.ItemHeight = 23;
            this.SemesterCombo.Items.AddRange(new object[] {
            "Semester1",
            "Semester2",
            "Semester3",
            "Semester4",
            "Semester5",
            "Semester6",
            "Semester7",
            "Semester8"});
            this.SemesterCombo.Location = new System.Drawing.Point(117, 38);
            this.SemesterCombo.Name = "SemesterCombo";
            this.SemesterCombo.Size = new System.Drawing.Size(174, 29);
            this.SemesterCombo.TabIndex = 70;
            this.SemesterCombo.UseSelectable = true;
            // 
            // Semester
            // 
            this.Semester.AutoSize = true;
            this.Semester.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Semester.Location = new System.Drawing.Point(15, 48);
            this.Semester.Name = "Semester";
            this.Semester.Size = new System.Drawing.Size(65, 19);
            this.Semester.TabIndex = 69;
            this.Semester.Text = "Semester";
            // 
            // RegNo
            // 
            this.RegNo.AutoSize = true;
            this.RegNo.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.RegNo.Location = new System.Drawing.Point(12, 11);
            this.RegNo.Name = "RegNo";
            this.RegNo.Size = new System.Drawing.Size(104, 19);
            this.RegNo.TabIndex = 63;
            this.RegNo.Text = "Registration No";
            // 
            // RegNoText
            // 
            // 
            // 
            // 
            this.RegNoText.CustomButton.Image = null;
            this.RegNoText.CustomButton.Location = new System.Drawing.Point(154, 2);
            this.RegNoText.CustomButton.Name = "";
            this.RegNoText.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.RegNoText.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.RegNoText.CustomButton.TabIndex = 1;
            this.RegNoText.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.RegNoText.CustomButton.UseSelectable = true;
            this.RegNoText.CustomButton.Visible = false;
            this.RegNoText.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.RegNoText.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.RegNoText.Lines = new string[] {
        "00-NTU-0000 example"};
            this.RegNoText.Location = new System.Drawing.Point(117, 8);
            this.RegNoText.MaxLength = 32767;
            this.RegNoText.Name = "RegNoText";
            this.RegNoText.PasswordChar = '\0';
            this.RegNoText.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.RegNoText.SelectedText = "";
            this.RegNoText.SelectionLength = 0;
            this.RegNoText.SelectionStart = 0;
            this.RegNoText.ShortcutsEnabled = true;
            this.RegNoText.Size = new System.Drawing.Size(174, 22);
            this.RegNoText.TabIndex = 64;
            this.RegNoText.Text = "00-NTU-0000 example";
            this.RegNoText.UseSelectable = true;
            this.RegNoText.WaterMarkColor = System.Drawing.Color.Gainsboro;
            this.RegNoText.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // techBindingSource1
            // 
            this.techBindingSource1.DataMember = "Tech";
            this.techBindingSource1.DataSource = this._C__ProjectDataSet31;
            // 
            // _C__ProjectDataSet31
            // 
            this._C__ProjectDataSet31.DataSetName = "_C__ProjectDataSet3";
            this._C__ProjectDataSet31.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // displineBindingSource1
            // 
            this.displineBindingSource1.DataMember = "Displine";
            this.displineBindingSource1.DataSource = this._C__ProjectDataSet2;
            // 
            // _C__ProjectDataSet2
            // 
            this._C__ProjectDataSet2.DataSetName = "_C__ProjectDataSet";
            this._C__ProjectDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // departCombo
            // 
            this.departCombo.DataSource = this.departmentBindingSource9;
            this.departCombo.DisplayMember = "DepTitle";
            this.departCombo.FormattingEnabled = true;
            this.departCombo.ItemHeight = 23;
            this.departCombo.Location = new System.Drawing.Point(694, 212);
            this.departCombo.Name = "departCombo";
            this.departCombo.Size = new System.Drawing.Size(174, 29);
            this.departCombo.TabIndex = 64;
            this.departCombo.UseSelectable = true;
            this.departCombo.ValueMember = "DepID";
            // 
            // departmentBindingSource7
            // 
            this.departmentBindingSource7.DataMember = "Department";
            this.departmentBindingSource7.DataSource = this._C__ProjectDataSet2;
            // 
            // Department
            // 
            this.Department.AutoSize = true;
            this.Department.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Department.Location = new System.Drawing.Point(588, 222);
            this.Department.Name = "Department";
            this.Department.Size = new System.Drawing.Size(83, 19);
            this.Department.TabIndex = 63;
            this.Department.Text = "Department";
            // 
            // departmentDataBindingSource2
            // 
            this.departmentDataBindingSource2.DataMember = "DepartmentData";
            this.departmentDataBindingSource2.DataSource = this.projectDataSet3;
            // 
            // projectDataSet3
            // 
            this.projectDataSet3.DataSetName = "ProjectDataSet3";
            this.projectDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // departmentBindingSource4
            // 
            this.departmentBindingSource4.DataMember = "Department";
            this.departmentBindingSource4.DataSource = this.projectDataSet2;
            // 
            // projectDataSet2
            // 
            this.projectDataSet2.DataSetName = "ProjectDataSet";
            this.projectDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // projectDataSet
            // 
            this.projectDataSet.DataSetName = "ProjectDataSet";
            this.projectDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Pic
            // 
            // 
            // 
            // 
            this.Pic.CustomButton.Image = null;
            this.Pic.CustomButton.Location = new System.Drawing.Point(154, 2);
            this.Pic.CustomButton.Name = "";
            this.Pic.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Pic.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Pic.CustomButton.TabIndex = 1;
            this.Pic.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Pic.CustomButton.UseSelectable = true;
            this.Pic.CustomButton.Visible = false;
            this.Pic.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Pic.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Pic.Lines = new string[0];
            this.Pic.Location = new System.Drawing.Point(694, 110);
            this.Pic.MaxLength = 32767;
            this.Pic.Name = "Pic";
            this.Pic.PasswordChar = '\0';
            this.Pic.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Pic.SelectedText = "";
            this.Pic.SelectionLength = 0;
            this.Pic.SelectionStart = 0;
            this.Pic.ShortcutsEnabled = true;
            this.Pic.Size = new System.Drawing.Size(174, 22);
            this.Pic.TabIndex = 76;
            this.Pic.UseSelectable = true;
            this.Pic.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Pic.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // departmentBindingSource
            // 
            this.departmentBindingSource.DataMember = "Department";
            this.departmentBindingSource.DataSource = this.projectDataSet;
            // 
            // departmentTableAdapter
            // 
            this.departmentTableAdapter.ClearBeforeFill = true;
            // 
            // projectDataSet1
            // 
            this.projectDataSet1.DataSetName = "ProjectDataSet1";
            this.projectDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // departmentBindingSource1
            // 
            this.departmentBindingSource1.DataMember = "Department";
            this.departmentBindingSource1.DataSource = this.projectDataSet1;
            // 
            // departmentTableAdapter1
            // 
            this.departmentTableAdapter1.ClearBeforeFill = true;
            // 
            // departmentBindingSource3
            // 
            this.departmentBindingSource3.DataMember = "Department";
            this.departmentBindingSource3.DataSource = this.projectDataSet;
            // 
            // departmentBindingSource2
            // 
            this.departmentBindingSource2.DataMember = "Department";
            this.departmentBindingSource2.DataSource = this.projectDataSet;
            // 
            // projectDataSetBindingSource
            // 
            this.projectDataSetBindingSource.DataSource = this.projectDataSet;
            this.projectDataSetBindingSource.Position = 0;
            // 
            // departmentBindingSource5
            // 
            this.departmentBindingSource5.DataMember = "Department";
            this.departmentBindingSource5.DataSource = this.projectDataSet2;
            // 
            // projectDataSet21
            // 
            this.projectDataSet21.DataSetName = "ProjectDataSet2";
            this.projectDataSet21.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // departmentDataBindingSource
            // 
            this.departmentDataBindingSource.DataMember = "DepartmentData";
            this.departmentDataBindingSource.DataSource = this.projectDataSet21;
            // 
            // departmentDataTableAdapter
            // 
            this.departmentDataTableAdapter.ClearBeforeFill = true;
            // 
            // fKUserDataDepID2A4B4B5EBindingSource
            // 
            this.fKUserDataDepID2A4B4B5EBindingSource.DataMember = "FK__UserData__DepID__2A4B4B5E";
            this.fKUserDataDepID2A4B4B5EBindingSource.DataSource = this.departmentDataBindingSource;
            // 
            // userDataTableAdapter
            // 
            this.userDataTableAdapter.ClearBeforeFill = true;
            // 
            // departmentDataBindingSource1
            // 
            this.departmentDataBindingSource1.DataMember = "DepartmentData";
            this.departmentDataBindingSource1.DataSource = this.projectDataSet21;
            // 
            // departmentDataTableAdapter1
            // 
            this.departmentDataTableAdapter1.ClearBeforeFill = true;
            // 
            // projectDataSet3BindingSource
            // 
            this.projectDataSet3BindingSource.DataSource = this.projectDataSet3;
            this.projectDataSet3BindingSource.Position = 0;
            // 
            // projectDataSet4
            // 
            this.projectDataSet4.DataSetName = "ProjectDataSet4";
            this.projectDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // userTypeBindingSource
            // 
            this.userTypeBindingSource.DataMember = "UserType";
            this.userTypeBindingSource.DataSource = this.projectDataSet4;
            // 
            // userTypeTableAdapter
            // 
            this.userTypeTableAdapter.ClearBeforeFill = true;
            // 
            // projectDataSet5
            // 
            this.projectDataSet5.DataSetName = "ProjectDataSet5";
            this.projectDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // uTypeBindingSource
            // 
            this.uTypeBindingSource.DataMember = "UType";
            this.uTypeBindingSource.DataSource = this.projectDataSet5;
            // 
            // uTypeTableAdapter
            // 
            this.uTypeTableAdapter.ClearBeforeFill = true;
            // 
            // uTypeBindingSource1
            // 
            this.uTypeBindingSource1.DataMember = "UType";
            this.uTypeBindingSource1.DataSource = this.projectDataSet5;
            // 
            // uTDataTableAdapter
            // 
            this.uTDataTableAdapter.ClearBeforeFill = true;
            // 
            // userTypeTableAdapter1
            // 
            this.userTypeTableAdapter1.ClearBeforeFill = true;
            // 
            // departmentBindingSource6
            // 
            this.departmentBindingSource6.DataMember = "Department";
            this.departmentBindingSource6.DataSource = this._C__ProjectDataSet;
            // 
            // departmentTableAdapter2
            // 
            this.departmentTableAdapter2.ClearBeforeFill = true;
            // 
            // _C__ProjectDataSet1
            // 
            this._C__ProjectDataSet1.DataSetName = "_C__ProjectDataSet";
            this._C__ProjectDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // displineBindingSource
            // 
            this.displineBindingSource.DataMember = "Displine";
            this.displineBindingSource.DataSource = this._C__ProjectDataSet1;
            // 
            // displineTableAdapter
            // 
            this.displineTableAdapter.ClearBeforeFill = true;
            // 
            // uTypeTableAdapter1
            // 
            this.uTypeTableAdapter1.ClearBeforeFill = true;
            // 
            // user_TypeTableAdapter
            // 
            this.user_TypeTableAdapter.ClearBeforeFill = true;
            // 
            // userDataBindingSource
            // 
            this.userDataBindingSource.DataMember = "UserData";
            this.userDataBindingSource.DataSource = this._C__ProjectDataSet3;
            // 
            // userDataTableAdapter1
            // 
            this.userDataTableAdapter1.ClearBeforeFill = true;
            // 
            // _C__ProjectDataSet21
            // 
            this._C__ProjectDataSet21.DataSetName = "_C__ProjectDataSet2";
            this._C__ProjectDataSet21.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // userDataBindingSource1
            // 
            this.userDataBindingSource1.DataMember = "UserData";
            this.userDataBindingSource1.DataSource = this._C__ProjectDataSet21;
            // 
            // userDataTableAdapter2
            // 
            this.userDataTableAdapter2.ClearBeforeFill = true;
            // 
            // semesterBindingSource
            // 
            this.semesterBindingSource.DataMember = "Semester";
            this.semesterBindingSource.DataSource = this._C__ProjectDataSet21;
            // 
            // semesterTableAdapter
            // 
            this.semesterTableAdapter.ClearBeforeFill = true;
            // 
            // techBindingSource
            // 
            this.techBindingSource.DataMember = "Tech";
            this.techBindingSource.DataSource = this._C__ProjectDataSet31;
            // 
            // techTableAdapter
            // 
            this.techTableAdapter.ClearBeforeFill = true;
            // 
            // Error
            // 
            this.Error.AutoSize = true;
            this.Error.Location = new System.Drawing.Point(367, 378);
            this.Error.Name = "Error";
            this.Error.Size = new System.Drawing.Size(0, 0);
            this.Error.TabIndex = 77;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Project.Properties.Resources.icons8_Restart_48px;
            this.pictureBox1.Location = new System.Drawing.Point(876, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(27, 28);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 78;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // TechCombo
            // 
            this.TechCombo.DataSource = this.techBindingSource1;
            this.TechCombo.DisplayMember = "TechID";
            this.TechCombo.FormattingEnabled = true;
            this.TechCombo.ItemHeight = 23;
            this.TechCombo.Location = new System.Drawing.Point(694, 250);
            this.TechCombo.Name = "TechCombo";
            this.TechCombo.Size = new System.Drawing.Size(174, 29);
            this.TechCombo.TabIndex = 80;
            this.TechCombo.UseSelectable = true;
            this.TechCombo.ValueMember = "Technology";
            // 
            // Tech
            // 
            this.Tech.AutoSize = true;
            this.Tech.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Tech.Location = new System.Drawing.Point(592, 260);
            this.Tech.Name = "Tech";
            this.Tech.Size = new System.Drawing.Size(85, 19);
            this.Tech.TabIndex = 79;
            this.Tech.Text = "Teachnology";
            // 
            // _C__ProjectDataSet7
            // 
            this._C__ProjectDataSet7.DataSetName = "_C__ProjectDataSet7";
            this._C__ProjectDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // departmentBindingSource8
            // 
            this.departmentBindingSource8.DataMember = "Department";
            this.departmentBindingSource8.DataSource = this._C__ProjectDataSet7;
            // 
            // departmentTableAdapter3
            // 
            this.departmentTableAdapter3.ClearBeforeFill = true;
            // 
            // departmentBindingSource9
            // 
            this.departmentBindingSource9.DataMember = "Department";
            this.departmentBindingSource9.DataSource = this._C__ProjectDataSet7;
            // 
            // SignIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(926, 506);
            this.Controls.Add(this.TechCombo);
            this.Controls.Add(this.Tech);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Error);
            this.Controls.Add(this.Pic);
            this.Controls.Add(this.Studentpanel);
            this.Controls.Add(this.metroButton2);
            this.Controls.Add(this.departCombo);
            this.Controls.Add(this.Image);
            this.Controls.Add(this.Department);
            this.Controls.Add(this.SigninButton);
            this.Controls.Add(this.UsertypeCombo);
            this.Controls.Add(this.Usertype);
            this.Controls.Add(this.Mobiletext);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.Emailtext);
            this.Controls.Add(this.Pass);
            this.Controls.Add(this.Usernametext);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.Username);
            this.Controls.Add(this.Gendercombo);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.Citytext);
            this.Controls.Add(this.Addresstext);
            this.Controls.Add(this.Fathernametext);
            this.Controls.Add(this.Lastnametext);
            this.Controls.Add(this.Firstnametext);
            this.Controls.Add(this.City);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.DateOfBirth);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.MobileNo);
            this.Controls.Add(this.FatherName);
            this.Controls.Add(this.LastName);
            this.Controls.Add(this.FirstName);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Movable = false;
            this.Name = "SignIn";
            this.Resizable = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Sign In";
            this.Theme = MetroFramework.MetroThemeStyle.Default;
            this.Load += new System.EventHandler(this.SignIn_Load);
            ((System.ComponentModel.ISupportInitialize)(this.userTypeBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userTypeBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userTypeBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uTypeBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userTypeBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uTDataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet6)).EndInit();
            this.Studentpanel.ResumeLayout(false);
            this.Studentpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.techBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.displineBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentDataBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentDataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKUserDataDepID2A4B4B5EBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentDataBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userTypeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uTypeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uTypeBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.displineBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userDataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userDataBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.semesterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.techBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroLabel Image;
        private MetroFramework.Controls.MetroButton SigninButton;
        private MetroFramework.Controls.MetroComboBox UsertypeCombo;
        private MetroFramework.Controls.MetroLabel Usertype;
        private System.Windows.Forms.MaskedTextBox Mobiletext;
        private MetroFramework.Controls.MetroTextBox Password;
        private MetroFramework.Controls.MetroTextBox Emailtext;
        private MetroFramework.Controls.MetroLabel Pass;
        private MetroFramework.Controls.MetroTextBox Usernametext;
        private MetroFramework.Controls.MetroLabel Email;
        private MetroFramework.Controls.MetroLabel Username;
        private MetroFramework.Controls.MetroComboBox Gendercombo;
        private MetroFramework.Controls.MetroDateTime Date;
        private MetroFramework.Controls.MetroTextBox Citytext;
        private MetroFramework.Controls.MetroTextBox Addresstext;
        private MetroFramework.Controls.MetroTextBox Fathernametext;
        private MetroFramework.Controls.MetroTextBox Lastnametext;
        private MetroFramework.Controls.MetroTextBox Firstnametext;
        private MetroFramework.Controls.MetroLabel City;
        private MetroFramework.Controls.MetroLabel Gender;
        private MetroFramework.Controls.MetroLabel DateOfBirth;
        private MetroFramework.Controls.MetroLabel Address;
        private MetroFramework.Controls.MetroLabel MobileNo;
        private MetroFramework.Controls.MetroLabel FatherName;
        private MetroFramework.Controls.MetroLabel LastName;
        private MetroFramework.Controls.MetroLabel FirstName;
        private System.Windows.Forms.Panel Studentpanel;
        private MetroFramework.Controls.MetroComboBox departCombo;
        private MetroFramework.Controls.MetroLabel Department;
        private MetroFramework.Controls.MetroTextBox RegNoText;
        private MetroFramework.Controls.MetroLabel RegNo;
        private MetroFramework.Controls.MetroTextBox Pic;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private ProjectDataSet projectDataSet;
        private System.Windows.Forms.BindingSource departmentBindingSource;
        private ProjectDataSetTableAdapters.DepartmentTableAdapter departmentTableAdapter;
        private ProjectDataSet1 projectDataSet1;
        private System.Windows.Forms.BindingSource departmentBindingSource1;
        private ProjectDataSet1TableAdapters.DepartmentTableAdapter departmentTableAdapter1;
        private System.Windows.Forms.BindingSource departmentBindingSource2;
        private System.Windows.Forms.BindingSource departmentBindingSource3;
        private System.Windows.Forms.BindingSource projectDataSetBindingSource;
        private ProjectDataSet projectDataSet2;
        private System.Windows.Forms.BindingSource departmentBindingSource4;
        private System.Windows.Forms.BindingSource departmentBindingSource5;
        private ProjectDataSet2 projectDataSet21;
        private System.Windows.Forms.BindingSource departmentDataBindingSource;
        private ProjectDataSet2TableAdapters.DepartmentDataTableAdapter departmentDataTableAdapter;
        private System.Windows.Forms.BindingSource fKUserDataDepID2A4B4B5EBindingSource;
        private ProjectDataSet2TableAdapters.UserDataTableAdapter userDataTableAdapter;
        private System.Windows.Forms.BindingSource departmentDataBindingSource1;
        private ProjectDataSet3 projectDataSet3;
        private System.Windows.Forms.BindingSource departmentDataBindingSource2;
        private ProjectDataSet3TableAdapters.DepartmentDataTableAdapter departmentDataTableAdapter1;
        private System.Windows.Forms.BindingSource projectDataSet3BindingSource;
        private ProjectDataSet4 projectDataSet4;
        private System.Windows.Forms.BindingSource userTypeBindingSource;
        private ProjectDataSet4TableAdapters.UserTypeTableAdapter userTypeTableAdapter;
        private ProjectDataSet5 projectDataSet5;
        private System.Windows.Forms.BindingSource uTypeBindingSource;
        private ProjectDataSet5TableAdapters.UTypeTableAdapter uTypeTableAdapter;
        private System.Windows.Forms.BindingSource uTypeBindingSource1;
        private ProjectDataSet6 projectDataSet6;
        private System.Windows.Forms.BindingSource uTDataBindingSource;
        private ProjectDataSet6TableAdapters.UTDataTableAdapter uTDataTableAdapter;
        private _C__ProjectDataSet _C__ProjectDataSet;
        private System.Windows.Forms.BindingSource userTypeBindingSource1;
        private _C__ProjectDataSetTableAdapters.UserTypeTableAdapter userTypeTableAdapter1;
        private System.Windows.Forms.BindingSource departmentBindingSource6;
        private _C__ProjectDataSetTableAdapters.DepartmentTableAdapter departmentTableAdapter2;
        private _C__ProjectDataSet _C__ProjectDataSet1;
        private System.Windows.Forms.BindingSource displineBindingSource;
        private _C__ProjectDataSetTableAdapters.DisplineTableAdapter displineTableAdapter;
        private _C__ProjectDataSet _C__ProjectDataSet2;
        private System.Windows.Forms.BindingSource displineBindingSource1;
        private System.Windows.Forms.BindingSource departmentBindingSource7;
        private System.Windows.Forms.BindingSource uTypeBindingSource2;
        private _C__ProjectDataSetTableAdapters.UTypeTableAdapter uTypeTableAdapter1;
        private _C__ProjectDataSet _C__ProjectDataSet3;
        private System.Windows.Forms.BindingSource userTypeBindingSource2;
        private System.Windows.Forms.BindingSource userTypeBindingSource3;
        private System.Windows.Forms.BindingSource userTypeBindingSource4;
        private _C__ProjectDataSetTableAdapters.User_TypeTableAdapter user_TypeTableAdapter;
        private MetroFramework.Controls.MetroComboBox SemesterCombo;
        private MetroFramework.Controls.MetroLabel Semester;
        private System.Windows.Forms.BindingSource userDataBindingSource;
        private _C__ProjectDataSetTableAdapters.UserDataTableAdapter userDataTableAdapter1;
        private _C__ProjectDataSet2 _C__ProjectDataSet21;
        private System.Windows.Forms.BindingSource userDataBindingSource1;
        private _C__ProjectDataSet2TableAdapters.UserDataTableAdapter userDataTableAdapter2;
        private System.Windows.Forms.BindingSource semesterBindingSource;
        private _C__ProjectDataSet2TableAdapters.SemesterTableAdapter semesterTableAdapter;
        private _C__ProjectDataSet3 _C__ProjectDataSet31;
        private System.Windows.Forms.BindingSource techBindingSource;
        private _C__ProjectDataSet3TableAdapters.TechTableAdapter techTableAdapter;
        private System.Windows.Forms.BindingSource techBindingSource1;
        private MetroFramework.Controls.MetroLabel Error;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MetroFramework.Controls.MetroComboBox TechCombo;
        private MetroFramework.Controls.MetroLabel Tech;
        private _C__ProjectDataSet7 _C__ProjectDataSet7;
        private System.Windows.Forms.BindingSource departmentBindingSource8;
        private _C__ProjectDataSet7TableAdapters.DepartmentTableAdapter departmentTableAdapter3;
        private System.Windows.Forms.BindingSource departmentBindingSource9;

    }
}