﻿namespace Project
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.userDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this._C__ProjectDataSet = new Project._C__ProjectDataSet();
            this.userDataTableAdapter = new Project._C__ProjectDataSetTableAdapters.UserDataTableAdapter();
            this.metroGrid1 = new MetroFramework.Controls.MetroGrid();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.Piclb = new MetroFramework.Controls.MetroLabel();
            this.FNamelb = new MetroFramework.Controls.MetroLabel();
            this.LNamelb = new MetroFramework.Controls.MetroLabel();
            this.FatherNamelb = new MetroFramework.Controls.MetroLabel();
            this.Moblb = new MetroFramework.Controls.MetroLabel();
            this.Addresslb = new MetroFramework.Controls.MetroLabel();
            this.DOBlb = new MetroFramework.Controls.MetroLabel();
            this.Genderlb = new MetroFramework.Controls.MetroLabel();
            this.Citylb = new MetroFramework.Controls.MetroLabel();
            this.FNametext = new MetroFramework.Controls.MetroTextBox();
            this.LNametext = new MetroFramework.Controls.MetroTextBox();
            this.FatherNametext = new MetroFramework.Controls.MetroTextBox();
            this.Addresstext = new MetroFramework.Controls.MetroTextBox();
            this.Citytext = new MetroFramework.Controls.MetroTextBox();
            this.Usernamelb = new MetroFramework.Controls.MetroLabel();
            this.Email_lb = new MetroFramework.Controls.MetroLabel();
            this.Usernametext = new MetroFramework.Controls.MetroTextBox();
            this.Passlb = new MetroFramework.Controls.MetroLabel();
            this.Emailtext = new MetroFramework.Controls.MetroTextBox();
            this.Passwordtext = new MetroFramework.Controls.MetroTextBox();
            this.Mobtext = new MetroFramework.Controls.MetroTextBox();
            this.DOBtext = new MetroFramework.Controls.MetroTextBox();
            this.Gendertext = new MetroFramework.Controls.MetroTextBox();
            this.Regtext = new MetroFramework.Controls.MetroTextBox();
            this.RegNo = new MetroFramework.Controls.MetroLabel();
            this.Usertypelb = new MetroFramework.Controls.MetroLabel();
            this.Departlb = new MetroFramework.Controls.MetroLabel();
            this.Techlb = new MetroFramework.Controls.MetroLabel();
            this.StudentPanel = new MetroFramework.Controls.MetroPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.CPGAtext = new System.Windows.Forms.TextBox();
            this.UserTypetext = new MetroFramework.Controls.MetroTextBox();
            this.Techtext = new MetroFramework.Controls.MetroTextBox();
            this.Deptext = new MetroFramework.Controls.MetroTextBox();
            this.TeachPanel = new MetroFramework.Controls.MetroPanel();
            this.Usertypetext1 = new MetroFramework.Controls.MetroTextBox();
            this.Techtext1 = new MetroFramework.Controls.MetroTextBox();
            this.Departtext1 = new MetroFramework.Controls.MetroTextBox();
            this.Techlb1 = new MetroFramework.Controls.MetroLabel();
            this.Departlb1 = new MetroFramework.Controls.MetroLabel();
            this.Usertypelb1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBox4 = new MetroFramework.Controls.MetroTextBox();
            this.Gendertext1 = new MetroFramework.Controls.MetroTextBox();
            this.DOBtext1 = new MetroFramework.Controls.MetroTextBox();
            this.Mobtext1 = new MetroFramework.Controls.MetroTextBox();
            this.Passtext1 = new MetroFramework.Controls.MetroTextBox();
            this.Emailtext1 = new MetroFramework.Controls.MetroTextBox();
            this.Passlb1 = new MetroFramework.Controls.MetroLabel();
            this.Usernametext1 = new MetroFramework.Controls.MetroTextBox();
            this.Email_lb1 = new MetroFramework.Controls.MetroLabel();
            this.Usernamelb1 = new MetroFramework.Controls.MetroLabel();
            this.Citytext1 = new MetroFramework.Controls.MetroTextBox();
            this.Addresstext1 = new MetroFramework.Controls.MetroTextBox();
            this.FatherNametext1 = new MetroFramework.Controls.MetroTextBox();
            this.LNametext1 = new MetroFramework.Controls.MetroTextBox();
            this.FNametext1 = new MetroFramework.Controls.MetroTextBox();
            this.Citylb1 = new MetroFramework.Controls.MetroLabel();
            this.Genderlb1 = new MetroFramework.Controls.MetroLabel();
            this.DOBlb1 = new MetroFramework.Controls.MetroLabel();
            this.Addresslb1 = new MetroFramework.Controls.MetroLabel();
            this.Moblb1 = new MetroFramework.Controls.MetroLabel();
            this.FatherNamelb1 = new MetroFramework.Controls.MetroLabel();
            this.LNamelb1 = new MetroFramework.Controls.MetroLabel();
            this.FNamelb1 = new MetroFramework.Controls.MetroLabel();
            this.Picturelb1 = new MetroFramework.Controls.MetroLabel();
            this.metroGrid2 = new MetroFramework.Controls.MetroGrid();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.TeacherPanel = new MetroFramework.Controls.MetroPanel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.CoursePanel = new MetroFramework.Controls.MetroPanel();
            this.Displine = new MetroFramework.Controls.MetroLabel();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.Semester = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.CourseTitle = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.CourseID = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroGrid3 = new MetroFramework.Controls.MetroGrid();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this._C__ProjectDataSet4 = new Project._C__ProjectDataSet4();
            this.courseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.courseTableAdapter = new Project._C__ProjectDataSet4TableAdapters.CourseTableAdapter();
            this.menu = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.metroLink1 = new MetroFramework.Controls.MetroLink();
            this.metroTile3 = new MetroFramework.Controls.MetroTile();
            this.metroTile2 = new MetroFramework.Controls.MetroTile();
            this.metroTile1 = new MetroFramework.Controls.MetroTile();
            this.CourseAsign = new MetroFramework.Controls.MetroTile();
            this.Picturetext1 = new System.Windows.Forms.PictureBox();
            this.UpdateTeacher = new MetroFramework.Controls.MetroTile();
            this.DeleteTeacher = new MetroFramework.Controls.MetroTile();
            this.Updatebtn = new MetroFramework.Controls.MetroTile();
            this.Deletebtn = new MetroFramework.Controls.MetroTile();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Coursebtn = new MetroFramework.Controls.MetroTile();
            this.Teacherbtn = new MetroFramework.Controls.MetroTile();
            this.Studentbtn = new MetroFramework.Controls.MetroTile();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userDataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).BeginInit();
            this.StudentPanel.SuspendLayout();
            this.TeachPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid2)).BeginInit();
            this.CoursePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.courseBindingSource)).BeginInit();
            this.menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Picturetext1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.pictureBox1);
            this.metroPanel1.Controls.Add(this.metroPanel2);
            this.metroPanel1.Controls.Add(this.Coursebtn);
            this.metroPanel1.Controls.Add(this.Teacherbtn);
            this.metroPanel1.Controls.Add(this.Studentbtn);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(13, 82);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(149, 439);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // metroPanel2
            // 
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(151, 2);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(677, 442);
            this.metroPanel2.TabIndex = 7;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            // 
            // userDataBindingSource
            // 
            this.userDataBindingSource.DataMember = "UserData";
            this.userDataBindingSource.DataSource = this._C__ProjectDataSet;
            // 
            // _C__ProjectDataSet
            // 
            this._C__ProjectDataSet.DataSetName = "_C__ProjectDataSet";
            this._C__ProjectDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // userDataTableAdapter
            // 
            this.userDataTableAdapter.ClearBeforeFill = true;
            // 
            // metroGrid1
            // 
            this.metroGrid1.AllowUserToAddRows = false;
            this.metroGrid1.AllowUserToDeleteRows = false;
            this.metroGrid1.AllowUserToResizeRows = false;
            this.metroGrid1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.metroGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid1.DefaultCellStyle = dataGridViewCellStyle2;
            this.metroGrid1.EnableHeadersVisualStyles = false;
            this.metroGrid1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.Location = new System.Drawing.Point(3, 115);
            this.metroGrid1.Name = "metroGrid1";
            this.metroGrid1.ReadOnly = true;
            this.metroGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.metroGrid1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid1.Size = new System.Drawing.Size(958, 200);
            this.metroGrid1.TabIndex = 2;
            this.metroGrid1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridview);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(12, 11);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(115, 25);
            this.metroLabel1.TabIndex = 13;
            this.metroLabel1.Text = "Student Data";
            // 
            // Piclb
            // 
            this.Piclb.AutoSize = true;
            this.Piclb.Location = new System.Drawing.Point(716, 356);
            this.Piclb.Name = "Piclb";
            this.Piclb.Size = new System.Drawing.Size(49, 19);
            this.Piclb.TabIndex = 32;
            this.Piclb.Text = "Picture";
            // 
            // FNamelb
            // 
            this.FNamelb.AutoSize = true;
            this.FNamelb.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.FNamelb.Location = new System.Drawing.Point(12, 359);
            this.FNamelb.Name = "FNamelb";
            this.FNamelb.Size = new System.Drawing.Size(75, 19);
            this.FNamelb.TabIndex = 57;
            this.FNamelb.Text = "First Name";
            // 
            // LNamelb
            // 
            this.LNamelb.AutoSize = true;
            this.LNamelb.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.LNamelb.Location = new System.Drawing.Point(12, 389);
            this.LNamelb.Name = "LNamelb";
            this.LNamelb.Size = new System.Drawing.Size(74, 19);
            this.LNamelb.TabIndex = 58;
            this.LNamelb.Text = "Last Name";
            // 
            // FatherNamelb
            // 
            this.FatherNamelb.AutoSize = true;
            this.FatherNamelb.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.FatherNamelb.Location = new System.Drawing.Point(12, 423);
            this.FatherNamelb.Name = "FatherNamelb";
            this.FatherNamelb.Size = new System.Drawing.Size(88, 19);
            this.FatherNamelb.TabIndex = 59;
            this.FatherNamelb.Text = "Father Name";
            // 
            // Moblb
            // 
            this.Moblb.AutoSize = true;
            this.Moblb.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Moblb.Location = new System.Drawing.Point(12, 457);
            this.Moblb.Name = "Moblb";
            this.Moblb.Size = new System.Drawing.Size(59, 19);
            this.Moblb.TabIndex = 60;
            this.Moblb.Text = "Mobile#";
            // 
            // Addresslb
            // 
            this.Addresslb.AutoSize = true;
            this.Addresslb.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Addresslb.Location = new System.Drawing.Point(12, 489);
            this.Addresslb.Name = "Addresslb";
            this.Addresslb.Size = new System.Drawing.Size(58, 19);
            this.Addresslb.TabIndex = 61;
            this.Addresslb.Text = "Address";
            // 
            // DOBlb
            // 
            this.DOBlb.AutoSize = true;
            this.DOBlb.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.DOBlb.Location = new System.Drawing.Point(365, 356);
            this.DOBlb.Name = "DOBlb";
            this.DOBlb.Size = new System.Drawing.Size(90, 19);
            this.DOBlb.TabIndex = 62;
            this.DOBlb.Text = "Date Of Birth";
            // 
            // Genderlb
            // 
            this.Genderlb.AutoSize = true;
            this.Genderlb.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Genderlb.Location = new System.Drawing.Point(365, 391);
            this.Genderlb.Name = "Genderlb";
            this.Genderlb.Size = new System.Drawing.Size(54, 19);
            this.Genderlb.TabIndex = 63;
            this.Genderlb.Text = "Gender";
            // 
            // Citylb
            // 
            this.Citylb.AutoSize = true;
            this.Citylb.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Citylb.Location = new System.Drawing.Point(365, 420);
            this.Citylb.Name = "Citylb";
            this.Citylb.Size = new System.Drawing.Size(33, 19);
            this.Citylb.TabIndex = 64;
            this.Citylb.Text = "City";
            // 
            // FNametext
            // 
            // 
            // 
            // 
            this.FNametext.CustomButton.Image = null;
            this.FNametext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.FNametext.CustomButton.Name = "";
            this.FNametext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.FNametext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.FNametext.CustomButton.TabIndex = 1;
            this.FNametext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.FNametext.CustomButton.UseSelectable = true;
            this.FNametext.CustomButton.Visible = false;
            this.FNametext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.FNametext.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.FNametext.Lines = new string[] {
        "First Name"};
            this.FNametext.Location = new System.Drawing.Point(143, 356);
            this.FNametext.MaxLength = 32767;
            this.FNametext.Name = "FNametext";
            this.FNametext.PasswordChar = '\0';
            this.FNametext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.FNametext.SelectedText = "";
            this.FNametext.SelectionLength = 0;
            this.FNametext.SelectionStart = 0;
            this.FNametext.ShortcutsEnabled = true;
            this.FNametext.Size = new System.Drawing.Size(188, 22);
            this.FNametext.TabIndex = 65;
            this.FNametext.Text = "First Name";
            this.FNametext.UseSelectable = true;
            this.FNametext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.FNametext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // LNametext
            // 
            // 
            // 
            // 
            this.LNametext.CustomButton.Image = null;
            this.LNametext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.LNametext.CustomButton.Name = "";
            this.LNametext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.LNametext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.LNametext.CustomButton.TabIndex = 1;
            this.LNametext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.LNametext.CustomButton.UseSelectable = true;
            this.LNametext.CustomButton.Visible = false;
            this.LNametext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.LNametext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.LNametext.Lines = new string[] {
        "Last Name"};
            this.LNametext.Location = new System.Drawing.Point(143, 386);
            this.LNametext.MaxLength = 32767;
            this.LNametext.Name = "LNametext";
            this.LNametext.PasswordChar = '\0';
            this.LNametext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.LNametext.SelectedText = "";
            this.LNametext.SelectionLength = 0;
            this.LNametext.SelectionStart = 0;
            this.LNametext.ShortcutsEnabled = true;
            this.LNametext.Size = new System.Drawing.Size(188, 22);
            this.LNametext.TabIndex = 66;
            this.LNametext.Text = "Last Name";
            this.LNametext.UseSelectable = true;
            this.LNametext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.LNametext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // FatherNametext
            // 
            // 
            // 
            // 
            this.FatherNametext.CustomButton.Image = null;
            this.FatherNametext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.FatherNametext.CustomButton.Name = "";
            this.FatherNametext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.FatherNametext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.FatherNametext.CustomButton.TabIndex = 1;
            this.FatherNametext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.FatherNametext.CustomButton.UseSelectable = true;
            this.FatherNametext.CustomButton.Visible = false;
            this.FatherNametext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.FatherNametext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.FatherNametext.Lines = new string[] {
        "Father Name"};
            this.FatherNametext.Location = new System.Drawing.Point(143, 420);
            this.FatherNametext.MaxLength = 32767;
            this.FatherNametext.Name = "FatherNametext";
            this.FatherNametext.PasswordChar = '\0';
            this.FatherNametext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.FatherNametext.SelectedText = "";
            this.FatherNametext.SelectionLength = 0;
            this.FatherNametext.SelectionStart = 0;
            this.FatherNametext.ShortcutsEnabled = true;
            this.FatherNametext.Size = new System.Drawing.Size(188, 22);
            this.FatherNametext.TabIndex = 67;
            this.FatherNametext.Text = "Father Name";
            this.FatherNametext.UseSelectable = true;
            this.FatherNametext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.FatherNametext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Addresstext
            // 
            // 
            // 
            // 
            this.Addresstext.CustomButton.Image = null;
            this.Addresstext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Addresstext.CustomButton.Name = "";
            this.Addresstext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Addresstext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Addresstext.CustomButton.TabIndex = 1;
            this.Addresstext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Addresstext.CustomButton.UseSelectable = true;
            this.Addresstext.CustomButton.Visible = false;
            this.Addresstext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Addresstext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Addresstext.Lines = new string[] {
        "Address"};
            this.Addresstext.Location = new System.Drawing.Point(143, 486);
            this.Addresstext.MaxLength = 32767;
            this.Addresstext.Name = "Addresstext";
            this.Addresstext.PasswordChar = '\0';
            this.Addresstext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Addresstext.SelectedText = "";
            this.Addresstext.SelectionLength = 0;
            this.Addresstext.SelectionStart = 0;
            this.Addresstext.ShortcutsEnabled = true;
            this.Addresstext.Size = new System.Drawing.Size(188, 22);
            this.Addresstext.TabIndex = 68;
            this.Addresstext.Text = "Address";
            this.Addresstext.UseSelectable = true;
            this.Addresstext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Addresstext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Citytext
            // 
            // 
            // 
            // 
            this.Citytext.CustomButton.Image = null;
            this.Citytext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Citytext.CustomButton.Name = "";
            this.Citytext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Citytext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Citytext.CustomButton.TabIndex = 1;
            this.Citytext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Citytext.CustomButton.UseSelectable = true;
            this.Citytext.CustomButton.Visible = false;
            this.Citytext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Citytext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Citytext.Lines = new string[] {
        "City"};
            this.Citytext.Location = new System.Drawing.Point(496, 417);
            this.Citytext.MaxLength = 32767;
            this.Citytext.Name = "Citytext";
            this.Citytext.PasswordChar = '\0';
            this.Citytext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Citytext.SelectedText = "";
            this.Citytext.SelectionLength = 0;
            this.Citytext.SelectionStart = 0;
            this.Citytext.ShortcutsEnabled = true;
            this.Citytext.Size = new System.Drawing.Size(188, 22);
            this.Citytext.TabIndex = 69;
            this.Citytext.Text = "City";
            this.Citytext.UseSelectable = true;
            this.Citytext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Citytext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Usernamelb
            // 
            this.Usernamelb.AutoSize = true;
            this.Usernamelb.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Usernamelb.Location = new System.Drawing.Point(365, 454);
            this.Usernamelb.Name = "Usernamelb";
            this.Usernamelb.Size = new System.Drawing.Size(77, 19);
            this.Usernamelb.TabIndex = 72;
            this.Usernamelb.Text = "User Name";
            // 
            // Email_lb
            // 
            this.Email_lb.AutoSize = true;
            this.Email_lb.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Email_lb.Location = new System.Drawing.Point(365, 487);
            this.Email_lb.Name = "Email_lb";
            this.Email_lb.Size = new System.Drawing.Size(41, 19);
            this.Email_lb.TabIndex = 73;
            this.Email_lb.Text = "Email";
            // 
            // Usernametext
            // 
            // 
            // 
            // 
            this.Usernametext.CustomButton.Image = null;
            this.Usernametext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Usernametext.CustomButton.Name = "";
            this.Usernametext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Usernametext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Usernametext.CustomButton.TabIndex = 1;
            this.Usernametext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Usernametext.CustomButton.UseSelectable = true;
            this.Usernametext.CustomButton.Visible = false;
            this.Usernametext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Usernametext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Usernametext.Lines = new string[] {
        "User Name"};
            this.Usernametext.Location = new System.Drawing.Point(496, 451);
            this.Usernametext.MaxLength = 32767;
            this.Usernametext.Name = "Usernametext";
            this.Usernametext.PasswordChar = '\0';
            this.Usernametext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Usernametext.SelectedText = "";
            this.Usernametext.SelectionLength = 0;
            this.Usernametext.SelectionStart = 0;
            this.Usernametext.ShortcutsEnabled = true;
            this.Usernametext.Size = new System.Drawing.Size(188, 22);
            this.Usernametext.TabIndex = 74;
            this.Usernametext.Text = "User Name";
            this.Usernametext.UseSelectable = true;
            this.Usernametext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Usernametext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Passlb
            // 
            this.Passlb.AutoSize = true;
            this.Passlb.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Passlb.Location = new System.Drawing.Point(365, 518);
            this.Passlb.Name = "Passlb";
            this.Passlb.Size = new System.Drawing.Size(67, 19);
            this.Passlb.TabIndex = 75;
            this.Passlb.Text = "Password";
            // 
            // Emailtext
            // 
            // 
            // 
            // 
            this.Emailtext.CustomButton.Image = null;
            this.Emailtext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Emailtext.CustomButton.Name = "";
            this.Emailtext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Emailtext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Emailtext.CustomButton.TabIndex = 1;
            this.Emailtext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Emailtext.CustomButton.UseSelectable = true;
            this.Emailtext.CustomButton.Visible = false;
            this.Emailtext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Emailtext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Emailtext.Lines = new string[] {
        "Email"};
            this.Emailtext.Location = new System.Drawing.Point(496, 484);
            this.Emailtext.MaxLength = 32767;
            this.Emailtext.Name = "Emailtext";
            this.Emailtext.PasswordChar = '\0';
            this.Emailtext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Emailtext.SelectedText = "";
            this.Emailtext.SelectionLength = 0;
            this.Emailtext.SelectionStart = 0;
            this.Emailtext.ShortcutsEnabled = true;
            this.Emailtext.Size = new System.Drawing.Size(188, 22);
            this.Emailtext.TabIndex = 76;
            this.Emailtext.Text = "Email";
            this.Emailtext.UseSelectable = true;
            this.Emailtext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Emailtext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Passwordtext
            // 
            // 
            // 
            // 
            this.Passwordtext.CustomButton.Image = null;
            this.Passwordtext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Passwordtext.CustomButton.Name = "";
            this.Passwordtext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Passwordtext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Passwordtext.CustomButton.TabIndex = 1;
            this.Passwordtext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Passwordtext.CustomButton.UseSelectable = true;
            this.Passwordtext.CustomButton.Visible = false;
            this.Passwordtext.Lines = new string[0];
            this.Passwordtext.Location = new System.Drawing.Point(496, 515);
            this.Passwordtext.MaxLength = 32767;
            this.Passwordtext.Name = "Passwordtext";
            this.Passwordtext.PasswordChar = '\0';
            this.Passwordtext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Passwordtext.SelectedText = "";
            this.Passwordtext.SelectionLength = 0;
            this.Passwordtext.SelectionStart = 0;
            this.Passwordtext.ShortcutsEnabled = true;
            this.Passwordtext.Size = new System.Drawing.Size(188, 22);
            this.Passwordtext.TabIndex = 77;
            this.Passwordtext.UseSelectable = true;
            this.Passwordtext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Passwordtext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Mobtext
            // 
            // 
            // 
            // 
            this.Mobtext.CustomButton.Image = null;
            this.Mobtext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Mobtext.CustomButton.Name = "";
            this.Mobtext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Mobtext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Mobtext.CustomButton.TabIndex = 1;
            this.Mobtext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Mobtext.CustomButton.UseSelectable = true;
            this.Mobtext.CustomButton.Visible = false;
            this.Mobtext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Mobtext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Mobtext.Lines = new string[] {
        "Mobile#"};
            this.Mobtext.Location = new System.Drawing.Point(143, 454);
            this.Mobtext.MaxLength = 32767;
            this.Mobtext.Name = "Mobtext";
            this.Mobtext.PasswordChar = '\0';
            this.Mobtext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Mobtext.SelectedText = "";
            this.Mobtext.SelectionLength = 0;
            this.Mobtext.SelectionStart = 0;
            this.Mobtext.ShortcutsEnabled = true;
            this.Mobtext.Size = new System.Drawing.Size(188, 22);
            this.Mobtext.TabIndex = 78;
            this.Mobtext.Text = "Mobile#";
            this.Mobtext.UseSelectable = true;
            this.Mobtext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Mobtext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // DOBtext
            // 
            // 
            // 
            // 
            this.DOBtext.CustomButton.Image = null;
            this.DOBtext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.DOBtext.CustomButton.Name = "";
            this.DOBtext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.DOBtext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.DOBtext.CustomButton.TabIndex = 1;
            this.DOBtext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.DOBtext.CustomButton.UseSelectable = true;
            this.DOBtext.CustomButton.Visible = false;
            this.DOBtext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.DOBtext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DOBtext.Lines = new string[] {
        "Date Of Birth"};
            this.DOBtext.Location = new System.Drawing.Point(496, 353);
            this.DOBtext.MaxLength = 32767;
            this.DOBtext.Name = "DOBtext";
            this.DOBtext.PasswordChar = '\0';
            this.DOBtext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.DOBtext.SelectedText = "";
            this.DOBtext.SelectionLength = 0;
            this.DOBtext.SelectionStart = 0;
            this.DOBtext.ShortcutsEnabled = true;
            this.DOBtext.Size = new System.Drawing.Size(188, 22);
            this.DOBtext.TabIndex = 79;
            this.DOBtext.Text = "Date Of Birth";
            this.DOBtext.UseSelectable = true;
            this.DOBtext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.DOBtext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Gendertext
            // 
            // 
            // 
            // 
            this.Gendertext.CustomButton.Image = null;
            this.Gendertext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Gendertext.CustomButton.Name = "";
            this.Gendertext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Gendertext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Gendertext.CustomButton.TabIndex = 1;
            this.Gendertext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Gendertext.CustomButton.UseSelectable = true;
            this.Gendertext.CustomButton.Visible = false;
            this.Gendertext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Gendertext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Gendertext.Lines = new string[] {
        "Gender"};
            this.Gendertext.Location = new System.Drawing.Point(496, 388);
            this.Gendertext.MaxLength = 32767;
            this.Gendertext.Name = "Gendertext";
            this.Gendertext.PasswordChar = '\0';
            this.Gendertext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Gendertext.SelectedText = "";
            this.Gendertext.SelectionLength = 0;
            this.Gendertext.SelectionStart = 0;
            this.Gendertext.ShortcutsEnabled = true;
            this.Gendertext.Size = new System.Drawing.Size(188, 22);
            this.Gendertext.TabIndex = 80;
            this.Gendertext.Text = "Gender";
            this.Gendertext.UseSelectable = true;
            this.Gendertext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Gendertext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Regtext
            // 
            // 
            // 
            // 
            this.Regtext.CustomButton.Image = null;
            this.Regtext.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Regtext.CustomButton.Name = "";
            this.Regtext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Regtext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Regtext.CustomButton.TabIndex = 1;
            this.Regtext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Regtext.CustomButton.UseSelectable = true;
            this.Regtext.CustomButton.Visible = false;
            this.Regtext.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Regtext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Regtext.Lines = new string[] {
        "00-NTU-0000 example"};
            this.Regtext.Location = new System.Drawing.Point(143, 518);
            this.Regtext.MaxLength = 32767;
            this.Regtext.Name = "Regtext";
            this.Regtext.PasswordChar = '\0';
            this.Regtext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Regtext.SelectedText = "";
            this.Regtext.SelectionLength = 0;
            this.Regtext.SelectionStart = 0;
            this.Regtext.ShortcutsEnabled = true;
            this.Regtext.Size = new System.Drawing.Size(188, 22);
            this.Regtext.TabIndex = 86;
            this.Regtext.Text = "00-NTU-0000 example";
            this.Regtext.UseSelectable = true;
            this.Regtext.WaterMarkColor = System.Drawing.Color.Gainsboro;
            this.Regtext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // RegNo
            // 
            this.RegNo.AutoSize = true;
            this.RegNo.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.RegNo.Location = new System.Drawing.Point(12, 518);
            this.RegNo.Name = "RegNo";
            this.RegNo.Size = new System.Drawing.Size(104, 19);
            this.RegNo.TabIndex = 84;
            this.RegNo.Text = "Registration No";
            // 
            // Usertypelb
            // 
            this.Usertypelb.AutoSize = true;
            this.Usertypelb.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Usertypelb.Location = new System.Drawing.Point(716, 545);
            this.Usertypelb.Name = "Usertypelb";
            this.Usertypelb.Size = new System.Drawing.Size(69, 19);
            this.Usertypelb.TabIndex = 81;
            this.Usertypelb.Text = "User Type";
            // 
            // Departlb
            // 
            this.Departlb.AutoSize = true;
            this.Departlb.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Departlb.Location = new System.Drawing.Point(716, 474);
            this.Departlb.Name = "Departlb";
            this.Departlb.Size = new System.Drawing.Size(83, 19);
            this.Departlb.TabIndex = 83;
            this.Departlb.Text = "Department";
            // 
            // Techlb
            // 
            this.Techlb.AutoSize = true;
            this.Techlb.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Techlb.Location = new System.Drawing.Point(716, 509);
            this.Techlb.Name = "Techlb";
            this.Techlb.Size = new System.Drawing.Size(85, 19);
            this.Techlb.TabIndex = 87;
            this.Techlb.Text = "Teachnology";
            // 
            // StudentPanel
            // 
            this.StudentPanel.Controls.Add(this.label1);
            this.StudentPanel.Controls.Add(this.CPGAtext);
            this.StudentPanel.Controls.Add(this.Updatebtn);
            this.StudentPanel.Controls.Add(this.Deletebtn);
            this.StudentPanel.Controls.Add(this.UserTypetext);
            this.StudentPanel.Controls.Add(this.Techtext);
            this.StudentPanel.Controls.Add(this.Deptext);
            this.StudentPanel.Controls.Add(this.Techlb);
            this.StudentPanel.Controls.Add(this.Departlb);
            this.StudentPanel.Controls.Add(this.Usertypelb);
            this.StudentPanel.Controls.Add(this.RegNo);
            this.StudentPanel.Controls.Add(this.Regtext);
            this.StudentPanel.Controls.Add(this.Gendertext);
            this.StudentPanel.Controls.Add(this.DOBtext);
            this.StudentPanel.Controls.Add(this.Mobtext);
            this.StudentPanel.Controls.Add(this.Passwordtext);
            this.StudentPanel.Controls.Add(this.Emailtext);
            this.StudentPanel.Controls.Add(this.Passlb);
            this.StudentPanel.Controls.Add(this.Usernametext);
            this.StudentPanel.Controls.Add(this.Email_lb);
            this.StudentPanel.Controls.Add(this.Usernamelb);
            this.StudentPanel.Controls.Add(this.Citytext);
            this.StudentPanel.Controls.Add(this.Addresstext);
            this.StudentPanel.Controls.Add(this.FatherNametext);
            this.StudentPanel.Controls.Add(this.LNametext);
            this.StudentPanel.Controls.Add(this.FNametext);
            this.StudentPanel.Controls.Add(this.Citylb);
            this.StudentPanel.Controls.Add(this.Genderlb);
            this.StudentPanel.Controls.Add(this.DOBlb);
            this.StudentPanel.Controls.Add(this.Addresslb);
            this.StudentPanel.Controls.Add(this.Moblb);
            this.StudentPanel.Controls.Add(this.FatherNamelb);
            this.StudentPanel.Controls.Add(this.LNamelb);
            this.StudentPanel.Controls.Add(this.FNamelb);
            this.StudentPanel.Controls.Add(this.Piclb);
            this.StudentPanel.Controls.Add(this.pictureBox2);
            this.StudentPanel.Controls.Add(this.metroLabel1);
            this.StudentPanel.Controls.Add(this.metroGrid1);
            this.StudentPanel.HorizontalScrollbarBarColor = true;
            this.StudentPanel.HorizontalScrollbarHighlightOnWheel = false;
            this.StudentPanel.HorizontalScrollbarSize = 10;
            this.StudentPanel.Location = new System.Drawing.Point(164, 82);
            this.StudentPanel.Name = "StudentPanel";
            this.StudentPanel.Size = new System.Drawing.Size(964, 582);
            this.StudentPanel.TabIndex = 1;
            this.StudentPanel.VerticalScrollbarBarColor = true;
            this.StudentPanel.VerticalScrollbarHighlightOnWheel = false;
            this.StudentPanel.VerticalScrollbarSize = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(367, 548);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "CPGA";
            // 
            // CPGAtext
            // 
            this.CPGAtext.Location = new System.Drawing.Point(496, 543);
            this.CPGAtext.Name = "CPGAtext";
            this.CPGAtext.Size = new System.Drawing.Size(188, 20);
            this.CPGAtext.TabIndex = 3;
            // 
            // UserTypetext
            // 
            // 
            // 
            // 
            this.UserTypetext.CustomButton.Image = null;
            this.UserTypetext.CustomButton.Location = new System.Drawing.Point(116, 2);
            this.UserTypetext.CustomButton.Name = "";
            this.UserTypetext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.UserTypetext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.UserTypetext.CustomButton.TabIndex = 1;
            this.UserTypetext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.UserTypetext.CustomButton.UseSelectable = true;
            this.UserTypetext.CustomButton.Visible = false;
            this.UserTypetext.Lines = new string[0];
            this.UserTypetext.Location = new System.Drawing.Point(805, 545);
            this.UserTypetext.MaxLength = 32767;
            this.UserTypetext.Name = "UserTypetext";
            this.UserTypetext.PasswordChar = '\0';
            this.UserTypetext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.UserTypetext.SelectedText = "";
            this.UserTypetext.SelectionLength = 0;
            this.UserTypetext.SelectionStart = 0;
            this.UserTypetext.ShortcutsEnabled = true;
            this.UserTypetext.Size = new System.Drawing.Size(136, 22);
            this.UserTypetext.TabIndex = 90;
            this.UserTypetext.UseSelectable = true;
            this.UserTypetext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.UserTypetext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Techtext
            // 
            // 
            // 
            // 
            this.Techtext.CustomButton.Image = null;
            this.Techtext.CustomButton.Location = new System.Drawing.Point(116, 2);
            this.Techtext.CustomButton.Name = "";
            this.Techtext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Techtext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Techtext.CustomButton.TabIndex = 1;
            this.Techtext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Techtext.CustomButton.UseSelectable = true;
            this.Techtext.CustomButton.Visible = false;
            this.Techtext.Lines = new string[0];
            this.Techtext.Location = new System.Drawing.Point(805, 509);
            this.Techtext.MaxLength = 32767;
            this.Techtext.Name = "Techtext";
            this.Techtext.PasswordChar = '\0';
            this.Techtext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Techtext.SelectedText = "";
            this.Techtext.SelectionLength = 0;
            this.Techtext.SelectionStart = 0;
            this.Techtext.ShortcutsEnabled = true;
            this.Techtext.Size = new System.Drawing.Size(136, 22);
            this.Techtext.TabIndex = 89;
            this.Techtext.UseSelectable = true;
            this.Techtext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Techtext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Deptext
            // 
            // 
            // 
            // 
            this.Deptext.CustomButton.Image = null;
            this.Deptext.CustomButton.Location = new System.Drawing.Point(116, 2);
            this.Deptext.CustomButton.Name = "";
            this.Deptext.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Deptext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Deptext.CustomButton.TabIndex = 1;
            this.Deptext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Deptext.CustomButton.UseSelectable = true;
            this.Deptext.CustomButton.Visible = false;
            this.Deptext.Lines = new string[0];
            this.Deptext.Location = new System.Drawing.Point(805, 474);
            this.Deptext.MaxLength = 32767;
            this.Deptext.Name = "Deptext";
            this.Deptext.PasswordChar = '\0';
            this.Deptext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Deptext.SelectedText = "";
            this.Deptext.SelectionLength = 0;
            this.Deptext.SelectionStart = 0;
            this.Deptext.ShortcutsEnabled = true;
            this.Deptext.Size = new System.Drawing.Size(136, 22);
            this.Deptext.TabIndex = 88;
            this.Deptext.UseSelectable = true;
            this.Deptext.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Deptext.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // TeachPanel
            // 
            this.TeachPanel.Controls.Add(this.CourseAsign);
            this.TeachPanel.Controls.Add(this.Usertypetext1);
            this.TeachPanel.Controls.Add(this.Techtext1);
            this.TeachPanel.Controls.Add(this.Departtext1);
            this.TeachPanel.Controls.Add(this.Techlb1);
            this.TeachPanel.Controls.Add(this.Departlb1);
            this.TeachPanel.Controls.Add(this.Usertypelb1);
            this.TeachPanel.Controls.Add(this.metroLabel7);
            this.TeachPanel.Controls.Add(this.metroTextBox4);
            this.TeachPanel.Controls.Add(this.Gendertext1);
            this.TeachPanel.Controls.Add(this.DOBtext1);
            this.TeachPanel.Controls.Add(this.Mobtext1);
            this.TeachPanel.Controls.Add(this.Passtext1);
            this.TeachPanel.Controls.Add(this.Emailtext1);
            this.TeachPanel.Controls.Add(this.Passlb1);
            this.TeachPanel.Controls.Add(this.Usernametext1);
            this.TeachPanel.Controls.Add(this.Email_lb1);
            this.TeachPanel.Controls.Add(this.Usernamelb1);
            this.TeachPanel.Controls.Add(this.Citytext1);
            this.TeachPanel.Controls.Add(this.Addresstext1);
            this.TeachPanel.Controls.Add(this.FatherNametext1);
            this.TeachPanel.Controls.Add(this.LNametext1);
            this.TeachPanel.Controls.Add(this.FNametext1);
            this.TeachPanel.Controls.Add(this.Citylb1);
            this.TeachPanel.Controls.Add(this.Genderlb1);
            this.TeachPanel.Controls.Add(this.DOBlb1);
            this.TeachPanel.Controls.Add(this.Addresslb1);
            this.TeachPanel.Controls.Add(this.Moblb1);
            this.TeachPanel.Controls.Add(this.FatherNamelb1);
            this.TeachPanel.Controls.Add(this.LNamelb1);
            this.TeachPanel.Controls.Add(this.FNamelb1);
            this.TeachPanel.Controls.Add(this.Picturelb1);
            this.TeachPanel.Controls.Add(this.Picturetext1);
            this.TeachPanel.Controls.Add(this.metroGrid2);
            this.TeachPanel.Controls.Add(this.UpdateTeacher);
            this.TeachPanel.Controls.Add(this.DeleteTeacher);
            this.TeachPanel.Controls.Add(this.metroLabel3);
            this.TeachPanel.HorizontalScrollbarBarColor = true;
            this.TeachPanel.HorizontalScrollbarHighlightOnWheel = false;
            this.TeachPanel.HorizontalScrollbarSize = 10;
            this.TeachPanel.Location = new System.Drawing.Point(164, 82);
            this.TeachPanel.Name = "TeachPanel";
            this.TeachPanel.Size = new System.Drawing.Size(964, 582);
            this.TeachPanel.TabIndex = 2;
            this.TeachPanel.VerticalScrollbarBarColor = true;
            this.TeachPanel.VerticalScrollbarHighlightOnWheel = false;
            this.TeachPanel.VerticalScrollbarSize = 10;
            this.TeachPanel.Visible = false;
            // 
            // Usertypetext1
            // 
            // 
            // 
            // 
            this.Usertypetext1.CustomButton.Image = null;
            this.Usertypetext1.CustomButton.Location = new System.Drawing.Point(116, 2);
            this.Usertypetext1.CustomButton.Name = "";
            this.Usertypetext1.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Usertypetext1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Usertypetext1.CustomButton.TabIndex = 1;
            this.Usertypetext1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Usertypetext1.CustomButton.UseSelectable = true;
            this.Usertypetext1.CustomButton.Visible = false;
            this.Usertypetext1.Lines = new string[0];
            this.Usertypetext1.Location = new System.Drawing.Point(815, 548);
            this.Usertypetext1.MaxLength = 32767;
            this.Usertypetext1.Name = "Usertypetext1";
            this.Usertypetext1.PasswordChar = '\0';
            this.Usertypetext1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Usertypetext1.SelectedText = "";
            this.Usertypetext1.SelectionLength = 0;
            this.Usertypetext1.SelectionStart = 0;
            this.Usertypetext1.ShortcutsEnabled = true;
            this.Usertypetext1.Size = new System.Drawing.Size(136, 22);
            this.Usertypetext1.TabIndex = 122;
            this.Usertypetext1.UseSelectable = true;
            this.Usertypetext1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Usertypetext1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Techtext1
            // 
            // 
            // 
            // 
            this.Techtext1.CustomButton.Image = null;
            this.Techtext1.CustomButton.Location = new System.Drawing.Point(116, 2);
            this.Techtext1.CustomButton.Name = "";
            this.Techtext1.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Techtext1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Techtext1.CustomButton.TabIndex = 1;
            this.Techtext1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Techtext1.CustomButton.UseSelectable = true;
            this.Techtext1.CustomButton.Visible = false;
            this.Techtext1.Lines = new string[0];
            this.Techtext1.Location = new System.Drawing.Point(815, 512);
            this.Techtext1.MaxLength = 32767;
            this.Techtext1.Name = "Techtext1";
            this.Techtext1.PasswordChar = '\0';
            this.Techtext1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Techtext1.SelectedText = "";
            this.Techtext1.SelectionLength = 0;
            this.Techtext1.SelectionStart = 0;
            this.Techtext1.ShortcutsEnabled = true;
            this.Techtext1.Size = new System.Drawing.Size(136, 22);
            this.Techtext1.TabIndex = 121;
            this.Techtext1.UseSelectable = true;
            this.Techtext1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Techtext1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Departtext1
            // 
            // 
            // 
            // 
            this.Departtext1.CustomButton.Image = null;
            this.Departtext1.CustomButton.Location = new System.Drawing.Point(116, 2);
            this.Departtext1.CustomButton.Name = "";
            this.Departtext1.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Departtext1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Departtext1.CustomButton.TabIndex = 1;
            this.Departtext1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Departtext1.CustomButton.UseSelectable = true;
            this.Departtext1.CustomButton.Visible = false;
            this.Departtext1.Lines = new string[0];
            this.Departtext1.Location = new System.Drawing.Point(815, 477);
            this.Departtext1.MaxLength = 32767;
            this.Departtext1.Name = "Departtext1";
            this.Departtext1.PasswordChar = '\0';
            this.Departtext1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Departtext1.SelectedText = "";
            this.Departtext1.SelectionLength = 0;
            this.Departtext1.SelectionStart = 0;
            this.Departtext1.ShortcutsEnabled = true;
            this.Departtext1.Size = new System.Drawing.Size(136, 22);
            this.Departtext1.TabIndex = 120;
            this.Departtext1.UseSelectable = true;
            this.Departtext1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Departtext1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Techlb1
            // 
            this.Techlb1.AutoSize = true;
            this.Techlb1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Techlb1.Location = new System.Drawing.Point(726, 512);
            this.Techlb1.Name = "Techlb1";
            this.Techlb1.Size = new System.Drawing.Size(85, 19);
            this.Techlb1.TabIndex = 119;
            this.Techlb1.Text = "Teachnology";
            // 
            // Departlb1
            // 
            this.Departlb1.AutoSize = true;
            this.Departlb1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Departlb1.Location = new System.Drawing.Point(726, 477);
            this.Departlb1.Name = "Departlb1";
            this.Departlb1.Size = new System.Drawing.Size(83, 19);
            this.Departlb1.TabIndex = 116;
            this.Departlb1.Text = "Department";
            // 
            // Usertypelb1
            // 
            this.Usertypelb1.AutoSize = true;
            this.Usertypelb1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Usertypelb1.Location = new System.Drawing.Point(726, 548);
            this.Usertypelb1.Name = "Usertypelb1";
            this.Usertypelb1.Size = new System.Drawing.Size(69, 19);
            this.Usertypelb1.TabIndex = 115;
            this.Usertypelb1.Text = "User Type";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel7.Location = new System.Drawing.Point(22, 521);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(104, 19);
            this.metroLabel7.TabIndex = 117;
            this.metroLabel7.Text = "Registration No";
            // 
            // metroTextBox4
            // 
            // 
            // 
            // 
            this.metroTextBox4.CustomButton.Image = null;
            this.metroTextBox4.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.metroTextBox4.CustomButton.Name = "";
            this.metroTextBox4.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.metroTextBox4.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox4.CustomButton.TabIndex = 1;
            this.metroTextBox4.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox4.CustomButton.UseSelectable = true;
            this.metroTextBox4.CustomButton.Visible = false;
            this.metroTextBox4.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.metroTextBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.metroTextBox4.Lines = new string[] {
        "00-NTU-0000 example"};
            this.metroTextBox4.Location = new System.Drawing.Point(153, 521);
            this.metroTextBox4.MaxLength = 32767;
            this.metroTextBox4.Name = "metroTextBox4";
            this.metroTextBox4.PasswordChar = '\0';
            this.metroTextBox4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox4.SelectedText = "";
            this.metroTextBox4.SelectionLength = 0;
            this.metroTextBox4.SelectionStart = 0;
            this.metroTextBox4.ShortcutsEnabled = true;
            this.metroTextBox4.Size = new System.Drawing.Size(188, 22);
            this.metroTextBox4.TabIndex = 118;
            this.metroTextBox4.Text = "00-NTU-0000 example";
            this.metroTextBox4.UseSelectable = true;
            this.metroTextBox4.WaterMarkColor = System.Drawing.Color.Gainsboro;
            this.metroTextBox4.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Gendertext1
            // 
            // 
            // 
            // 
            this.Gendertext1.CustomButton.Image = null;
            this.Gendertext1.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Gendertext1.CustomButton.Name = "";
            this.Gendertext1.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Gendertext1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Gendertext1.CustomButton.TabIndex = 1;
            this.Gendertext1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Gendertext1.CustomButton.UseSelectable = true;
            this.Gendertext1.CustomButton.Visible = false;
            this.Gendertext1.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Gendertext1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Gendertext1.Lines = new string[] {
        "Gender"};
            this.Gendertext1.Location = new System.Drawing.Point(506, 391);
            this.Gendertext1.MaxLength = 32767;
            this.Gendertext1.Name = "Gendertext1";
            this.Gendertext1.PasswordChar = '\0';
            this.Gendertext1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Gendertext1.SelectedText = "";
            this.Gendertext1.SelectionLength = 0;
            this.Gendertext1.SelectionStart = 0;
            this.Gendertext1.ShortcutsEnabled = true;
            this.Gendertext1.Size = new System.Drawing.Size(188, 22);
            this.Gendertext1.TabIndex = 114;
            this.Gendertext1.Text = "Gender";
            this.Gendertext1.UseSelectable = true;
            this.Gendertext1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Gendertext1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // DOBtext1
            // 
            // 
            // 
            // 
            this.DOBtext1.CustomButton.Image = null;
            this.DOBtext1.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.DOBtext1.CustomButton.Name = "";
            this.DOBtext1.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.DOBtext1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.DOBtext1.CustomButton.TabIndex = 1;
            this.DOBtext1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.DOBtext1.CustomButton.UseSelectable = true;
            this.DOBtext1.CustomButton.Visible = false;
            this.DOBtext1.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.DOBtext1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DOBtext1.Lines = new string[] {
        "Date Of Birth"};
            this.DOBtext1.Location = new System.Drawing.Point(506, 356);
            this.DOBtext1.MaxLength = 32767;
            this.DOBtext1.Name = "DOBtext1";
            this.DOBtext1.PasswordChar = '\0';
            this.DOBtext1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.DOBtext1.SelectedText = "";
            this.DOBtext1.SelectionLength = 0;
            this.DOBtext1.SelectionStart = 0;
            this.DOBtext1.ShortcutsEnabled = true;
            this.DOBtext1.Size = new System.Drawing.Size(188, 22);
            this.DOBtext1.TabIndex = 113;
            this.DOBtext1.Text = "Date Of Birth";
            this.DOBtext1.UseSelectable = true;
            this.DOBtext1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.DOBtext1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Mobtext1
            // 
            // 
            // 
            // 
            this.Mobtext1.CustomButton.Image = null;
            this.Mobtext1.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Mobtext1.CustomButton.Name = "";
            this.Mobtext1.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Mobtext1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Mobtext1.CustomButton.TabIndex = 1;
            this.Mobtext1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Mobtext1.CustomButton.UseSelectable = true;
            this.Mobtext1.CustomButton.Visible = false;
            this.Mobtext1.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Mobtext1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Mobtext1.Lines = new string[] {
        "Mobile#"};
            this.Mobtext1.Location = new System.Drawing.Point(153, 457);
            this.Mobtext1.MaxLength = 32767;
            this.Mobtext1.Name = "Mobtext1";
            this.Mobtext1.PasswordChar = '\0';
            this.Mobtext1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Mobtext1.SelectedText = "";
            this.Mobtext1.SelectionLength = 0;
            this.Mobtext1.SelectionStart = 0;
            this.Mobtext1.ShortcutsEnabled = true;
            this.Mobtext1.Size = new System.Drawing.Size(188, 22);
            this.Mobtext1.TabIndex = 112;
            this.Mobtext1.Text = "Mobile#";
            this.Mobtext1.UseSelectable = true;
            this.Mobtext1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Mobtext1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Passtext1
            // 
            // 
            // 
            // 
            this.Passtext1.CustomButton.Image = null;
            this.Passtext1.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Passtext1.CustomButton.Name = "";
            this.Passtext1.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Passtext1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Passtext1.CustomButton.TabIndex = 1;
            this.Passtext1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Passtext1.CustomButton.UseSelectable = true;
            this.Passtext1.CustomButton.Visible = false;
            this.Passtext1.Lines = new string[0];
            this.Passtext1.Location = new System.Drawing.Point(506, 518);
            this.Passtext1.MaxLength = 32767;
            this.Passtext1.Name = "Passtext1";
            this.Passtext1.PasswordChar = '\0';
            this.Passtext1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Passtext1.SelectedText = "";
            this.Passtext1.SelectionLength = 0;
            this.Passtext1.SelectionStart = 0;
            this.Passtext1.ShortcutsEnabled = true;
            this.Passtext1.Size = new System.Drawing.Size(188, 22);
            this.Passtext1.TabIndex = 111;
            this.Passtext1.UseSelectable = true;
            this.Passtext1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Passtext1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Emailtext1
            // 
            // 
            // 
            // 
            this.Emailtext1.CustomButton.Image = null;
            this.Emailtext1.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Emailtext1.CustomButton.Name = "";
            this.Emailtext1.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Emailtext1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Emailtext1.CustomButton.TabIndex = 1;
            this.Emailtext1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Emailtext1.CustomButton.UseSelectable = true;
            this.Emailtext1.CustomButton.Visible = false;
            this.Emailtext1.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Emailtext1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Emailtext1.Lines = new string[] {
        "Email"};
            this.Emailtext1.Location = new System.Drawing.Point(506, 487);
            this.Emailtext1.MaxLength = 32767;
            this.Emailtext1.Name = "Emailtext1";
            this.Emailtext1.PasswordChar = '\0';
            this.Emailtext1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Emailtext1.SelectedText = "";
            this.Emailtext1.SelectionLength = 0;
            this.Emailtext1.SelectionStart = 0;
            this.Emailtext1.ShortcutsEnabled = true;
            this.Emailtext1.Size = new System.Drawing.Size(188, 22);
            this.Emailtext1.TabIndex = 110;
            this.Emailtext1.Text = "Email";
            this.Emailtext1.UseSelectable = true;
            this.Emailtext1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Emailtext1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Passlb1
            // 
            this.Passlb1.AutoSize = true;
            this.Passlb1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Passlb1.Location = new System.Drawing.Point(375, 521);
            this.Passlb1.Name = "Passlb1";
            this.Passlb1.Size = new System.Drawing.Size(67, 19);
            this.Passlb1.TabIndex = 109;
            this.Passlb1.Text = "Password";
            // 
            // Usernametext1
            // 
            // 
            // 
            // 
            this.Usernametext1.CustomButton.Image = null;
            this.Usernametext1.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Usernametext1.CustomButton.Name = "";
            this.Usernametext1.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Usernametext1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Usernametext1.CustomButton.TabIndex = 1;
            this.Usernametext1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Usernametext1.CustomButton.UseSelectable = true;
            this.Usernametext1.CustomButton.Visible = false;
            this.Usernametext1.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Usernametext1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Usernametext1.Lines = new string[] {
        "User Name"};
            this.Usernametext1.Location = new System.Drawing.Point(506, 454);
            this.Usernametext1.MaxLength = 32767;
            this.Usernametext1.Name = "Usernametext1";
            this.Usernametext1.PasswordChar = '\0';
            this.Usernametext1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Usernametext1.SelectedText = "";
            this.Usernametext1.SelectionLength = 0;
            this.Usernametext1.SelectionStart = 0;
            this.Usernametext1.ShortcutsEnabled = true;
            this.Usernametext1.Size = new System.Drawing.Size(188, 22);
            this.Usernametext1.TabIndex = 108;
            this.Usernametext1.Text = "User Name";
            this.Usernametext1.UseSelectable = true;
            this.Usernametext1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Usernametext1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Email_lb1
            // 
            this.Email_lb1.AutoSize = true;
            this.Email_lb1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Email_lb1.Location = new System.Drawing.Point(375, 490);
            this.Email_lb1.Name = "Email_lb1";
            this.Email_lb1.Size = new System.Drawing.Size(41, 19);
            this.Email_lb1.TabIndex = 107;
            this.Email_lb1.Text = "Email";
            // 
            // Usernamelb1
            // 
            this.Usernamelb1.AutoSize = true;
            this.Usernamelb1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Usernamelb1.Location = new System.Drawing.Point(375, 457);
            this.Usernamelb1.Name = "Usernamelb1";
            this.Usernamelb1.Size = new System.Drawing.Size(77, 19);
            this.Usernamelb1.TabIndex = 106;
            this.Usernamelb1.Text = "User Name";
            // 
            // Citytext1
            // 
            // 
            // 
            // 
            this.Citytext1.CustomButton.Image = null;
            this.Citytext1.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Citytext1.CustomButton.Name = "";
            this.Citytext1.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Citytext1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Citytext1.CustomButton.TabIndex = 1;
            this.Citytext1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Citytext1.CustomButton.UseSelectable = true;
            this.Citytext1.CustomButton.Visible = false;
            this.Citytext1.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Citytext1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Citytext1.Lines = new string[] {
        "City"};
            this.Citytext1.Location = new System.Drawing.Point(506, 420);
            this.Citytext1.MaxLength = 32767;
            this.Citytext1.Name = "Citytext1";
            this.Citytext1.PasswordChar = '\0';
            this.Citytext1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Citytext1.SelectedText = "";
            this.Citytext1.SelectionLength = 0;
            this.Citytext1.SelectionStart = 0;
            this.Citytext1.ShortcutsEnabled = true;
            this.Citytext1.Size = new System.Drawing.Size(188, 22);
            this.Citytext1.TabIndex = 105;
            this.Citytext1.Text = "City";
            this.Citytext1.UseSelectable = true;
            this.Citytext1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Citytext1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Addresstext1
            // 
            // 
            // 
            // 
            this.Addresstext1.CustomButton.Image = null;
            this.Addresstext1.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.Addresstext1.CustomButton.Name = "";
            this.Addresstext1.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.Addresstext1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Addresstext1.CustomButton.TabIndex = 1;
            this.Addresstext1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Addresstext1.CustomButton.UseSelectable = true;
            this.Addresstext1.CustomButton.Visible = false;
            this.Addresstext1.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.Addresstext1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Addresstext1.Lines = new string[] {
        "Address"};
            this.Addresstext1.Location = new System.Drawing.Point(153, 489);
            this.Addresstext1.MaxLength = 32767;
            this.Addresstext1.Name = "Addresstext1";
            this.Addresstext1.PasswordChar = '\0';
            this.Addresstext1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Addresstext1.SelectedText = "";
            this.Addresstext1.SelectionLength = 0;
            this.Addresstext1.SelectionStart = 0;
            this.Addresstext1.ShortcutsEnabled = true;
            this.Addresstext1.Size = new System.Drawing.Size(188, 22);
            this.Addresstext1.TabIndex = 104;
            this.Addresstext1.Text = "Address";
            this.Addresstext1.UseSelectable = true;
            this.Addresstext1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Addresstext1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // FatherNametext1
            // 
            // 
            // 
            // 
            this.FatherNametext1.CustomButton.Image = null;
            this.FatherNametext1.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.FatherNametext1.CustomButton.Name = "";
            this.FatherNametext1.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.FatherNametext1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.FatherNametext1.CustomButton.TabIndex = 1;
            this.FatherNametext1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.FatherNametext1.CustomButton.UseSelectable = true;
            this.FatherNametext1.CustomButton.Visible = false;
            this.FatherNametext1.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.FatherNametext1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.FatherNametext1.Lines = new string[] {
        "Father Name"};
            this.FatherNametext1.Location = new System.Drawing.Point(153, 423);
            this.FatherNametext1.MaxLength = 32767;
            this.FatherNametext1.Name = "FatherNametext1";
            this.FatherNametext1.PasswordChar = '\0';
            this.FatherNametext1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.FatherNametext1.SelectedText = "";
            this.FatherNametext1.SelectionLength = 0;
            this.FatherNametext1.SelectionStart = 0;
            this.FatherNametext1.ShortcutsEnabled = true;
            this.FatherNametext1.Size = new System.Drawing.Size(188, 22);
            this.FatherNametext1.TabIndex = 103;
            this.FatherNametext1.Text = "Father Name";
            this.FatherNametext1.UseSelectable = true;
            this.FatherNametext1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.FatherNametext1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // LNametext1
            // 
            // 
            // 
            // 
            this.LNametext1.CustomButton.Image = null;
            this.LNametext1.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.LNametext1.CustomButton.Name = "";
            this.LNametext1.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.LNametext1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.LNametext1.CustomButton.TabIndex = 1;
            this.LNametext1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.LNametext1.CustomButton.UseSelectable = true;
            this.LNametext1.CustomButton.Visible = false;
            this.LNametext1.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.LNametext1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.LNametext1.Lines = new string[] {
        "Last Name"};
            this.LNametext1.Location = new System.Drawing.Point(153, 389);
            this.LNametext1.MaxLength = 32767;
            this.LNametext1.Name = "LNametext1";
            this.LNametext1.PasswordChar = '\0';
            this.LNametext1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.LNametext1.SelectedText = "";
            this.LNametext1.SelectionLength = 0;
            this.LNametext1.SelectionStart = 0;
            this.LNametext1.ShortcutsEnabled = true;
            this.LNametext1.Size = new System.Drawing.Size(188, 22);
            this.LNametext1.TabIndex = 102;
            this.LNametext1.Text = "Last Name";
            this.LNametext1.UseSelectable = true;
            this.LNametext1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.LNametext1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // FNametext1
            // 
            // 
            // 
            // 
            this.FNametext1.CustomButton.Image = null;
            this.FNametext1.CustomButton.Location = new System.Drawing.Point(168, 2);
            this.FNametext1.CustomButton.Name = "";
            this.FNametext1.CustomButton.Size = new System.Drawing.Size(17, 17);
            this.FNametext1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.FNametext1.CustomButton.TabIndex = 1;
            this.FNametext1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.FNametext1.CustomButton.UseSelectable = true;
            this.FNametext1.CustomButton.Visible = false;
            this.FNametext1.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.FNametext1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.FNametext1.Lines = new string[] {
        "First Name"};
            this.FNametext1.Location = new System.Drawing.Point(153, 359);
            this.FNametext1.MaxLength = 32767;
            this.FNametext1.Name = "FNametext1";
            this.FNametext1.PasswordChar = '\0';
            this.FNametext1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.FNametext1.SelectedText = "";
            this.FNametext1.SelectionLength = 0;
            this.FNametext1.SelectionStart = 0;
            this.FNametext1.ShortcutsEnabled = true;
            this.FNametext1.Size = new System.Drawing.Size(188, 22);
            this.FNametext1.TabIndex = 101;
            this.FNametext1.Text = "First Name";
            this.FNametext1.UseSelectable = true;
            this.FNametext1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.FNametext1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Citylb1
            // 
            this.Citylb1.AutoSize = true;
            this.Citylb1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Citylb1.Location = new System.Drawing.Point(375, 423);
            this.Citylb1.Name = "Citylb1";
            this.Citylb1.Size = new System.Drawing.Size(33, 19);
            this.Citylb1.TabIndex = 100;
            this.Citylb1.Text = "City";
            // 
            // Genderlb1
            // 
            this.Genderlb1.AutoSize = true;
            this.Genderlb1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Genderlb1.Location = new System.Drawing.Point(375, 394);
            this.Genderlb1.Name = "Genderlb1";
            this.Genderlb1.Size = new System.Drawing.Size(54, 19);
            this.Genderlb1.TabIndex = 99;
            this.Genderlb1.Text = "Gender";
            // 
            // DOBlb1
            // 
            this.DOBlb1.AutoSize = true;
            this.DOBlb1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.DOBlb1.Location = new System.Drawing.Point(375, 359);
            this.DOBlb1.Name = "DOBlb1";
            this.DOBlb1.Size = new System.Drawing.Size(90, 19);
            this.DOBlb1.TabIndex = 98;
            this.DOBlb1.Text = "Date Of Birth";
            // 
            // Addresslb1
            // 
            this.Addresslb1.AutoSize = true;
            this.Addresslb1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Addresslb1.Location = new System.Drawing.Point(22, 492);
            this.Addresslb1.Name = "Addresslb1";
            this.Addresslb1.Size = new System.Drawing.Size(58, 19);
            this.Addresslb1.TabIndex = 97;
            this.Addresslb1.Text = "Address";
            // 
            // Moblb1
            // 
            this.Moblb1.AutoSize = true;
            this.Moblb1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.Moblb1.Location = new System.Drawing.Point(22, 460);
            this.Moblb1.Name = "Moblb1";
            this.Moblb1.Size = new System.Drawing.Size(59, 19);
            this.Moblb1.TabIndex = 96;
            this.Moblb1.Text = "Mobile#";
            // 
            // FatherNamelb1
            // 
            this.FatherNamelb1.AutoSize = true;
            this.FatherNamelb1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.FatherNamelb1.Location = new System.Drawing.Point(22, 426);
            this.FatherNamelb1.Name = "FatherNamelb1";
            this.FatherNamelb1.Size = new System.Drawing.Size(88, 19);
            this.FatherNamelb1.TabIndex = 95;
            this.FatherNamelb1.Text = "Father Name";
            // 
            // LNamelb1
            // 
            this.LNamelb1.AutoSize = true;
            this.LNamelb1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.LNamelb1.Location = new System.Drawing.Point(22, 392);
            this.LNamelb1.Name = "LNamelb1";
            this.LNamelb1.Size = new System.Drawing.Size(74, 19);
            this.LNamelb1.TabIndex = 94;
            this.LNamelb1.Text = "Last Name";
            // 
            // FNamelb1
            // 
            this.FNamelb1.AutoSize = true;
            this.FNamelb1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.FNamelb1.Location = new System.Drawing.Point(22, 362);
            this.FNamelb1.Name = "FNamelb1";
            this.FNamelb1.Size = new System.Drawing.Size(75, 19);
            this.FNamelb1.TabIndex = 93;
            this.FNamelb1.Text = "First Name";
            // 
            // Picturelb1
            // 
            this.Picturelb1.AutoSize = true;
            this.Picturelb1.Location = new System.Drawing.Point(726, 359);
            this.Picturelb1.Name = "Picturelb1";
            this.Picturelb1.Size = new System.Drawing.Size(49, 19);
            this.Picturelb1.TabIndex = 92;
            this.Picturelb1.Text = "Picture";
            // 
            // metroGrid2
            // 
            this.metroGrid2.AllowUserToAddRows = false;
            this.metroGrid2.AllowUserToDeleteRows = false;
            this.metroGrid2.AllowUserToResizeRows = false;
            this.metroGrid2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.metroGrid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid2.DefaultCellStyle = dataGridViewCellStyle5;
            this.metroGrid2.EnableHeadersVisualStyles = false;
            this.metroGrid2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid2.Location = new System.Drawing.Point(4, 116);
            this.metroGrid2.Name = "metroGrid2";
            this.metroGrid2.ReadOnly = true;
            this.metroGrid2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid2.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.metroGrid2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid2.Size = new System.Drawing.Size(953, 190);
            this.metroGrid2.TabIndex = 36;
            this.metroGrid2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridview1);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(12, 11);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(112, 25);
            this.metroLabel3.TabIndex = 14;
            this.metroLabel3.Text = "Teacher Data";
            // 
            // TeacherPanel
            // 
            this.TeacherPanel.HorizontalScrollbarBarColor = true;
            this.TeacherPanel.HorizontalScrollbarHighlightOnWheel = false;
            this.TeacherPanel.HorizontalScrollbarSize = 10;
            this.TeacherPanel.Location = new System.Drawing.Point(0, 0);
            this.TeacherPanel.Name = "TeacherPanel";
            this.TeacherPanel.Size = new System.Drawing.Size(200, 100);
            this.TeacherPanel.TabIndex = 0;
            this.TeacherPanel.VerticalScrollbarBarColor = true;
            this.TeacherPanel.VerticalScrollbarHighlightOnWheel = false;
            this.TeacherPanel.VerticalScrollbarSize = 10;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(164, 18);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(112, 25);
            this.metroLabel2.TabIndex = 14;
            this.metroLabel2.Text = "Teacher Data";
            // 
            // CoursePanel
            // 
            this.CoursePanel.Controls.Add(this.metroTile3);
            this.CoursePanel.Controls.Add(this.metroTile2);
            this.CoursePanel.Controls.Add(this.metroTile1);
            this.CoursePanel.Controls.Add(this.Displine);
            this.CoursePanel.Controls.Add(this.metroLabel12);
            this.CoursePanel.Controls.Add(this.Semester);
            this.CoursePanel.Controls.Add(this.metroLabel10);
            this.CoursePanel.Controls.Add(this.CourseTitle);
            this.CoursePanel.Controls.Add(this.metroLabel8);
            this.CoursePanel.Controls.Add(this.CourseID);
            this.CoursePanel.Controls.Add(this.metroLabel5);
            this.CoursePanel.Controls.Add(this.metroGrid3);
            this.CoursePanel.Controls.Add(this.metroLabel4);
            this.CoursePanel.HorizontalScrollbarBarColor = true;
            this.CoursePanel.HorizontalScrollbarHighlightOnWheel = false;
            this.CoursePanel.HorizontalScrollbarSize = 10;
            this.CoursePanel.Location = new System.Drawing.Point(164, 82);
            this.CoursePanel.Name = "CoursePanel";
            this.CoursePanel.Size = new System.Drawing.Size(964, 582);
            this.CoursePanel.TabIndex = 124;
            this.CoursePanel.VerticalScrollbarBarColor = true;
            this.CoursePanel.VerticalScrollbarHighlightOnWheel = false;
            this.CoursePanel.VerticalScrollbarSize = 10;
            this.CoursePanel.Visible = false;
            // 
            // Displine
            // 
            this.Displine.AutoSize = true;
            this.Displine.Location = new System.Drawing.Point(183, 524);
            this.Displine.Name = "Displine";
            this.Displine.Size = new System.Drawing.Size(0, 0);
            this.Displine.TabIndex = 11;
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.Location = new System.Drawing.Point(36, 524);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(67, 19);
            this.metroLabel12.TabIndex = 10;
            this.metroLabel12.Text = "Discipline ";
            // 
            // Semester
            // 
            this.Semester.AutoSize = true;
            this.Semester.Location = new System.Drawing.Point(184, 492);
            this.Semester.Name = "Semester";
            this.Semester.Size = new System.Drawing.Size(0, 0);
            this.Semester.TabIndex = 9;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(36, 492);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(63, 19);
            this.metroLabel10.TabIndex = 8;
            this.metroLabel10.Text = "Semester";
            // 
            // CourseTitle
            // 
            this.CourseTitle.AutoSize = true;
            this.CourseTitle.Location = new System.Drawing.Point(186, 460);
            this.CourseTitle.Name = "CourseTitle";
            this.CourseTitle.Size = new System.Drawing.Size(0, 0);
            this.CourseTitle.TabIndex = 7;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(39, 460);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(78, 19);
            this.metroLabel8.TabIndex = 6;
            this.metroLabel8.Text = "Course Title";
            // 
            // CourseID
            // 
            this.CourseID.AutoSize = true;
            this.CourseID.Location = new System.Drawing.Point(186, 426);
            this.CourseID.Name = "CourseID";
            this.CourseID.Size = new System.Drawing.Size(0, 0);
            this.CourseID.TabIndex = 5;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(39, 426);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(62, 19);
            this.metroLabel5.TabIndex = 4;
            this.metroLabel5.Text = "CourseID";
            // 
            // metroGrid3
            // 
            this.metroGrid3.AllowUserToAddRows = false;
            this.metroGrid3.AllowUserToDeleteRows = false;
            this.metroGrid3.AllowUserToResizeRows = false;
            this.metroGrid3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid3.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.metroGrid3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid3.DefaultCellStyle = dataGridViewCellStyle8;
            this.metroGrid3.EnableHeadersVisualStyles = false;
            this.metroGrid3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid3.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid3.Location = new System.Drawing.Point(27, 169);
            this.metroGrid3.Name = "metroGrid3";
            this.metroGrid3.ReadOnly = true;
            this.metroGrid3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid3.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.metroGrid3.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid3.Size = new System.Drawing.Size(647, 239);
            this.metroGrid3.TabIndex = 3;
            this.metroGrid3.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.metroGrid3_CellContentClick);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(27, 29);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(117, 25);
            this.metroLabel4.TabIndex = 2;
            this.metroLabel4.Text = "Course Detail";
            // 
            // _C__ProjectDataSet4
            // 
            this._C__ProjectDataSet4.DataSetName = "_C__ProjectDataSet4";
            this._C__ProjectDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // courseBindingSource
            // 
            this.courseBindingSource.DataMember = "Course";
            this.courseBindingSource.DataSource = this._C__ProjectDataSet4;
            // 
            // courseTableAdapter
            // 
            this.courseTableAdapter.ClearBeforeFill = true;
            // 
            // menu
            // 
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logOutToolStripMenuItem});
            this.menu.Name = "menu";
            this.menu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menu.Size = new System.Drawing.Size(118, 26);
            // 
            // metroLink1
            // 
            this.metroLink1.BackgroundImage = global::Project.Properties.Resources.icons8_Pull_Down_36px;
            this.metroLink1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.metroLink1.Location = new System.Drawing.Point(1048, 24);
            this.metroLink1.Name = "metroLink1";
            this.metroLink1.Size = new System.Drawing.Size(40, 39);
            this.metroLink1.TabIndex = 125;
            this.metroLink1.UseSelectable = true;
            this.metroLink1.Click += new System.EventHandler(this.metroLink1_Click);
            // 
            // metroTile3
            // 
            this.metroTile3.ActiveControl = null;
            this.metroTile3.Location = new System.Drawing.Point(615, 69);
            this.metroTile3.Name = "metroTile3";
            this.metroTile3.Size = new System.Drawing.Size(130, 54);
            this.metroTile3.TabIndex = 14;
            this.metroTile3.Text = "Delete";
            this.metroTile3.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.metroTile3.TileImage = global::Project.Properties.Resources.icons8_Course_48px;
            this.metroTile3.UseSelectable = true;
            this.metroTile3.UseTileImage = true;
            this.metroTile3.Click += new System.EventHandler(this.metroTile3_Click);
            // 
            // metroTile2
            // 
            this.metroTile2.ActiveControl = null;
            this.metroTile2.Location = new System.Drawing.Point(387, 69);
            this.metroTile2.Name = "metroTile2";
            this.metroTile2.Size = new System.Drawing.Size(130, 54);
            this.metroTile2.TabIndex = 13;
            this.metroTile2.Text = "Update";
            this.metroTile2.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.metroTile2.TileImage = global::Project.Properties.Resources.icons8_Course_48px;
            this.metroTile2.UseSelectable = true;
            this.metroTile2.UseTileImage = true;
            this.metroTile2.Click += new System.EventHandler(this.metroTile2_Click);
            // 
            // metroTile1
            // 
            this.metroTile1.ActiveControl = null;
            this.metroTile1.Location = new System.Drawing.Point(167, 69);
            this.metroTile1.Name = "metroTile1";
            this.metroTile1.Size = new System.Drawing.Size(130, 54);
            this.metroTile1.TabIndex = 12;
            this.metroTile1.Text = "Add Course";
            this.metroTile1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.metroTile1.TileImage = global::Project.Properties.Resources.icons8_Course_48px;
            this.metroTile1.UseSelectable = true;
            this.metroTile1.UseTileImage = true;
            this.metroTile1.Click += new System.EventHandler(this.metroTile1_Click_1);
            // 
            // CourseAsign
            // 
            this.CourseAsign.ActiveControl = null;
            this.CourseAsign.Location = new System.Drawing.Point(523, 51);
            this.CourseAsign.Name = "CourseAsign";
            this.CourseAsign.Size = new System.Drawing.Size(151, 44);
            this.CourseAsign.TabIndex = 123;
            this.CourseAsign.Text = "Course Assign";
            this.CourseAsign.TileImage = global::Project.Properties.Resources.icons8_Edit_Property_48px;
            this.CourseAsign.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.CourseAsign.UseSelectable = true;
            this.CourseAsign.UseTileImage = true;
            this.CourseAsign.Click += new System.EventHandler(this.CourseAsign_Click);
            // 
            // Picturetext1
            // 
            this.Picturetext1.Location = new System.Drawing.Point(815, 359);
            this.Picturetext1.Name = "Picturetext1";
            this.Picturetext1.Size = new System.Drawing.Size(136, 100);
            this.Picturetext1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Picturetext1.TabIndex = 91;
            this.Picturetext1.TabStop = false;
            // 
            // UpdateTeacher
            // 
            this.UpdateTeacher.ActiveControl = null;
            this.UpdateTeacher.Location = new System.Drawing.Point(113, 51);
            this.UpdateTeacher.Name = "UpdateTeacher";
            this.UpdateTeacher.Size = new System.Drawing.Size(127, 44);
            this.UpdateTeacher.TabIndex = 34;
            this.UpdateTeacher.Text = "Update Data";
            this.UpdateTeacher.TileImage = global::Project.Properties.Resources.icons8_Edit_Profile_48px;
            this.UpdateTeacher.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.UpdateTeacher.UseSelectable = true;
            this.UpdateTeacher.UseTileImage = true;
            this.UpdateTeacher.Click += new System.EventHandler(this.UpdateTeacher_Click);
            // 
            // DeleteTeacher
            // 
            this.DeleteTeacher.ActiveControl = null;
            this.DeleteTeacher.Location = new System.Drawing.Point(318, 51);
            this.DeleteTeacher.Name = "DeleteTeacher";
            this.DeleteTeacher.Size = new System.Drawing.Size(127, 44);
            this.DeleteTeacher.TabIndex = 35;
            this.DeleteTeacher.Text = "Delete Data";
            this.DeleteTeacher.TileImage = global::Project.Properties.Resources.icons8_Denied_48px;
            this.DeleteTeacher.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.DeleteTeacher.UseSelectable = true;
            this.DeleteTeacher.UseTileImage = true;
            this.DeleteTeacher.Click += new System.EventHandler(this.DeleteTeacher_Click);
            // 
            // Updatebtn
            // 
            this.Updatebtn.ActiveControl = null;
            this.Updatebtn.Location = new System.Drawing.Point(90, 66);
            this.Updatebtn.Name = "Updatebtn";
            this.Updatebtn.Size = new System.Drawing.Size(127, 44);
            this.Updatebtn.TabIndex = 14;
            this.Updatebtn.Text = "Update Data";
            this.Updatebtn.TileImage = global::Project.Properties.Resources.icons8_Edit_Profile_48px;
            this.Updatebtn.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.Updatebtn.UseSelectable = true;
            this.Updatebtn.UseTileImage = true;
            this.Updatebtn.Click += new System.EventHandler(this.Updatebtn_Click);
            // 
            // Deletebtn
            // 
            this.Deletebtn.ActiveControl = null;
            this.Deletebtn.Location = new System.Drawing.Point(291, 66);
            this.Deletebtn.Name = "Deletebtn";
            this.Deletebtn.Size = new System.Drawing.Size(128, 44);
            this.Deletebtn.TabIndex = 33;
            this.Deletebtn.Text = "Delete Data";
            this.Deletebtn.TileImage = global::Project.Properties.Resources.icons8_Denied_48px;
            this.Deletebtn.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.Deletebtn.UseSelectable = true;
            this.Deletebtn.UseTileImage = true;
            this.Deletebtn.Click += new System.EventHandler(this.Deletebtn_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(805, 356);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(136, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 31;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Project.Properties.Resources.icons8_Add_User_Group_Woman_Man_48px;
            this.pictureBox1.Location = new System.Drawing.Point(45, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 51);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // Coursebtn
            // 
            this.Coursebtn.ActiveControl = null;
            this.Coursebtn.Location = new System.Drawing.Point(10, 276);
            this.Coursebtn.Name = "Coursebtn";
            this.Coursebtn.Size = new System.Drawing.Size(130, 54);
            this.Coursebtn.TabIndex = 4;
            this.Coursebtn.Text = "Course";
            this.Coursebtn.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.Coursebtn.TileImage = global::Project.Properties.Resources.icons8_Course_48px;
            this.Coursebtn.UseSelectable = true;
            this.Coursebtn.UseTileImage = true;
            this.Coursebtn.Click += new System.EventHandler(this.Coursebtn_Click);
            // 
            // Teacherbtn
            // 
            this.Teacherbtn.ActiveControl = null;
            this.Teacherbtn.Location = new System.Drawing.Point(10, 191);
            this.Teacherbtn.Name = "Teacherbtn";
            this.Teacherbtn.Size = new System.Drawing.Size(130, 54);
            this.Teacherbtn.TabIndex = 3;
            this.Teacherbtn.Text = "Teacher";
            this.Teacherbtn.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.Teacherbtn.TileImage = global::Project.Properties.Resources.icons8_School_Director_48px;
            this.Teacherbtn.UseSelectable = true;
            this.Teacherbtn.UseTileImage = true;
            this.Teacherbtn.Click += new System.EventHandler(this.Teacherbtn_Click);
            // 
            // Studentbtn
            // 
            this.Studentbtn.ActiveControl = null;
            this.Studentbtn.Location = new System.Drawing.Point(10, 106);
            this.Studentbtn.Name = "Studentbtn";
            this.Studentbtn.Size = new System.Drawing.Size(130, 54);
            this.Studentbtn.TabIndex = 2;
            this.Studentbtn.Text = "Student";
            this.Studentbtn.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.Studentbtn.TileImage = global::Project.Properties.Resources.icons8_Students_48px;
            this.Studentbtn.UseSelectable = true;
            this.Studentbtn.UseTileImage = true;
            this.Studentbtn.Click += new System.EventHandler(this.metroTile1_Click);
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Image = global::Project.Properties.Resources.icons8_Exit_48px;
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.logOutToolStripMenuItem.Text = "Log Out";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1137, 687);
            this.Controls.Add(this.metroLink1);
            this.Controls.Add(this.CoursePanel);
            this.Controls.Add(this.TeachPanel);
            this.Controls.Add(this.StudentPanel);
            this.Controls.Add(this.metroPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Movable = false;
            this.Name = "Admin";
            this.Resizable = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.Admin_Load);
            this.metroPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.userDataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).EndInit();
            this.StudentPanel.ResumeLayout(false);
            this.StudentPanel.PerformLayout();
            this.TeachPanel.ResumeLayout(false);
            this.TeachPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid2)).EndInit();
            this.CoursePanel.ResumeLayout(false);
            this.CoursePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__ProjectDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.courseBindingSource)).EndInit();
            this.menu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Picturetext1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroTile Studentbtn;
        private MetroFramework.Controls.MetroTile Coursebtn;
        private MetroFramework.Controls.MetroTile Teacherbtn;
        private MetroFramework.Controls.MetroPanel metroPanel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private _C__ProjectDataSet _C__ProjectDataSet;
        private System.Windows.Forms.BindingSource userDataBindingSource;
        private _C__ProjectDataSetTableAdapters.UserDataTableAdapter userDataTableAdapter;
        private MetroFramework.Controls.MetroGrid metroGrid1;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTile Updatebtn;
        private System.Windows.Forms.PictureBox pictureBox2;
        private MetroFramework.Controls.MetroLabel Piclb;
        private MetroFramework.Controls.MetroTile Deletebtn;
        private MetroFramework.Controls.MetroLabel FNamelb;
        private MetroFramework.Controls.MetroLabel LNamelb;
        private MetroFramework.Controls.MetroLabel FatherNamelb;
        private MetroFramework.Controls.MetroLabel Moblb;
        private MetroFramework.Controls.MetroLabel Addresslb;
        private MetroFramework.Controls.MetroLabel DOBlb;
        private MetroFramework.Controls.MetroLabel Genderlb;
        private MetroFramework.Controls.MetroLabel Citylb;
        private MetroFramework.Controls.MetroTextBox FNametext;
        private MetroFramework.Controls.MetroTextBox LNametext;
        private MetroFramework.Controls.MetroTextBox FatherNametext;
        private MetroFramework.Controls.MetroTextBox Addresstext;
        private MetroFramework.Controls.MetroTextBox Citytext;
        private MetroFramework.Controls.MetroLabel Usernamelb;
        private MetroFramework.Controls.MetroLabel Email_lb;
        private MetroFramework.Controls.MetroTextBox Usernametext;
        private MetroFramework.Controls.MetroLabel Passlb;
        private MetroFramework.Controls.MetroTextBox Emailtext;
        private MetroFramework.Controls.MetroTextBox Passwordtext;
        private MetroFramework.Controls.MetroTextBox Mobtext;
        private MetroFramework.Controls.MetroTextBox DOBtext;
        private MetroFramework.Controls.MetroTextBox Gendertext;
        private MetroFramework.Controls.MetroTextBox Regtext;
        private MetroFramework.Controls.MetroLabel RegNo;
        private MetroFramework.Controls.MetroLabel Usertypelb;
        private MetroFramework.Controls.MetroLabel Departlb;
        private MetroFramework.Controls.MetroLabel Techlb;
        private MetroFramework.Controls.MetroPanel StudentPanel;
        private MetroFramework.Controls.MetroTextBox UserTypetext;
        private MetroFramework.Controls.MetroTextBox Techtext;
        private MetroFramework.Controls.MetroTextBox Deptext;
        private MetroFramework.Controls.MetroPanel TeacherPanel;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroPanel TeachPanel;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTile UpdateTeacher;
        private MetroFramework.Controls.MetroTile DeleteTeacher;
        private MetroFramework.Controls.MetroTextBox Usertypetext1;
        private MetroFramework.Controls.MetroTextBox Techtext1;
        private MetroFramework.Controls.MetroTextBox Departtext1;
        private MetroFramework.Controls.MetroLabel Techlb1;
        private MetroFramework.Controls.MetroLabel Departlb1;
        private MetroFramework.Controls.MetroLabel Usertypelb1;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroTextBox metroTextBox4;
        private MetroFramework.Controls.MetroTextBox Gendertext1;
        private MetroFramework.Controls.MetroTextBox DOBtext1;
        private MetroFramework.Controls.MetroTextBox Mobtext1;
        private MetroFramework.Controls.MetroTextBox Passtext1;
        private MetroFramework.Controls.MetroTextBox Emailtext1;
        private MetroFramework.Controls.MetroLabel Passlb1;
        private MetroFramework.Controls.MetroTextBox Usernametext1;
        private MetroFramework.Controls.MetroLabel Email_lb1;
        private MetroFramework.Controls.MetroLabel Usernamelb1;
        private MetroFramework.Controls.MetroTextBox Citytext1;
        private MetroFramework.Controls.MetroTextBox Addresstext1;
        private MetroFramework.Controls.MetroTextBox FatherNametext1;
        private MetroFramework.Controls.MetroTextBox LNametext1;
        private MetroFramework.Controls.MetroTextBox FNametext1;
        private MetroFramework.Controls.MetroLabel Citylb1;
        private MetroFramework.Controls.MetroLabel Genderlb1;
        private MetroFramework.Controls.MetroLabel DOBlb1;
        private MetroFramework.Controls.MetroLabel Addresslb1;
        private MetroFramework.Controls.MetroLabel Moblb1;
        private MetroFramework.Controls.MetroLabel FatherNamelb1;
        private MetroFramework.Controls.MetroLabel LNamelb1;
        private MetroFramework.Controls.MetroLabel FNamelb1;
        private MetroFramework.Controls.MetroLabel Picturelb1;
        private System.Windows.Forms.PictureBox Picturetext1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox CPGAtext;
        private MetroFramework.Controls.MetroTile CourseAsign;
        private MetroFramework.Controls.MetroPanel CoursePanel;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroGrid metroGrid3;
        private _C__ProjectDataSet4 _C__ProjectDataSet4;
        private System.Windows.Forms.BindingSource courseBindingSource;
        private _C__ProjectDataSet4TableAdapters.CourseTableAdapter courseTableAdapter;
        private MetroFramework.Controls.MetroLink metroLink1;
        private MetroFramework.Controls.MetroContextMenu menu;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private MetroFramework.Controls.MetroLabel Displine;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel Semester;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel CourseTitle;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel CourseID;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroGrid metroGrid2;
        private MetroFramework.Controls.MetroTile metroTile3;
        private MetroFramework.Controls.MetroTile metroTile2;
        private MetroFramework.Controls.MetroTile metroTile1;
    }
}